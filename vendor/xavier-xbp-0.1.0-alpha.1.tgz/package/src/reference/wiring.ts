import type { Transport } from "../transport/transport.js";
import type { ReferenceHost } from "./host.js";

export function serveHost(
	host: ReferenceHost,
	transport: Transport,
): () => void {
	return transport.onFrame((frame) => {
		const ack = host.handle(frame);
		if (ack) {
			void transport.send(ack);
		}
	});
}

export async function requestOnce(
	transport: Transport,
	frame: Uint8Array,
	timeoutMs = 2000,
): Promise<Uint8Array> {
	return new Promise<Uint8Array>((resolve, reject) => {
		const off = transport.onFrame((response) => {
			off();
			resolve(response);
		});
		const timer = setTimeout(() => {
			off();
			reject(new Error("requestOnce: timed out"));
		}, timeoutMs);
		if (typeof timer.unref === "function") {
			timer.unref();
		}
		transport.send(frame).catch((err) => {
			off();
			clearTimeout(timer);
			reject(err);
		});
	});
}
