import { networkInterfaces, type NetworkInterfaceInfo } from "node:os";

// Returns the first non-internal IPv4 address (the Mac's LAN IP), or null if the
// machine has no LAN interface. The interfaces argument is injectable for tests.
export function getLanAddress(
	interfaces: NodeJS.Dict<NetworkInterfaceInfo[]> = networkInterfaces(),
): string | null {
	for (const infos of Object.values(interfaces)) {
		for (const info of infos ?? []) {
			if (info.family === "IPv4" && !info.internal) {
				return info.address;
			}
		}
	}
	return null;
}
