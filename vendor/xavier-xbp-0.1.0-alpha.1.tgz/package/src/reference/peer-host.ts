import {
	SESSION_CHANGED_TOPIC,
	sessionReportCapability,
	type SessionReportResult,
} from "@ai-creed/command-contract";
import type { NodeId } from "../peer/node-id.js";
import type { Peer } from "../peer/peer.js";

// A fixed, structured sample so the phone has something real to render in Slice
// 1 before ai-14all implements the host edge (Slice 2). Two sessions exercise
// the attention chip, escalation dot, workflow line, and the null-field paths.
export const SESSION_REPORT_STUB: SessionReportResult = {
	mode: "ready",
	focus: "wt-xavier",
	sessions: [
		{
			worktreeId: "wt-xavier",
			repo: "ai-xavier",
			branch: "master",
			provider: "claude",
			attention: "waiting",
			summary: "awaiting answer on the mesh foundation plan",
			task: "implement session-report over the Peer",
			nextAction: "answer question above",
			reviewCount: 1,
			escalation: { reason: "needs human judgment" },
			workflow: {
				workflowType: "spec-driven-development",
				status: "running",
				phaseName: "implement",
			},
			live: true,
			updatedAt: 1_700_000_000_000,
			recent: [
				{
					at: 1_700_000_000_000,
					from: "active",
					to: "waiting",
					summary: "awaiting answer on the mesh foundation plan",
					source: "mcp",
				},
			],
		},
		{
			worktreeId: "wt-14all",
			repo: "ai-14all",
			branch: "feat/contract",
			provider: "codex",
			attention: "active",
			summary: "consuming the shared command contract",
			task: null,
			nextAction: null,
			reviewCount: 0,
			escalation: null,
			workflow: null,
			live: true,
			updatedAt: 1_700_000_000_500,
			recent: [],
		},
	],
};

export function exposeSessionReport(peer: Peer): void {
	peer.expose(sessionReportCapability, () => SESSION_REPORT_STUB);
}

export function emitSampleSessionChanged(peer: Peer, to: NodeId): void {
	peer.emit(to, SESSION_CHANGED_TOPIC, { worktreeId: "wt-xavier" });
}
