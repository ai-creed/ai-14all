export interface ReplayResult {
	ok: boolean;
	reason?: "nonce-reused" | "stale-timestamp";
}

export class AntiReplay {
	private readonly seen = new Set<string>();

	constructor(
		private readonly windowMs = 30_000,
		private readonly now: () => number = () => Date.now(),
	) {}

	check(nonce: string, ts: number): ReplayResult {
		if (Math.abs(this.now() - ts) > this.windowMs) {
			return { ok: false, reason: "stale-timestamp" };
		}
		if (this.seen.has(nonce)) {
			return { ok: false, reason: "nonce-reused" };
		}
		this.seen.add(nonce);
		return { ok: true };
	}
}
