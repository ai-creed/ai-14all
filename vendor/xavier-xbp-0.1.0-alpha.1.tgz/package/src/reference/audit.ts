import { appendFileSync, existsSync, readFileSync } from "node:fs";
import type { Risk } from "../protocol/registry.js";

export interface AuditEntry {
	ts: number;
	cap: string | null;
	risk: Risk | null;
	outcome: "accepted" | "rejected";
	reason?: string;
}

export class AuditLog {
	constructor(
		private readonly path: string,
		private readonly now: () => number = () => Date.now(),
	) {}

	append(entry: Omit<AuditEntry, "ts">): void {
		const full: AuditEntry = { ts: this.now(), ...entry };
		appendFileSync(this.path, `${JSON.stringify(full)}\n`);
	}

	entries(): AuditEntry[] {
		if (!existsSync(this.path)) {
			return [];
		}
		return readFileSync(this.path, "utf8")
			.split("\n")
			.filter((line) => line.length > 0)
			.map((line) => JSON.parse(line) as AuditEntry);
	}
}
