import type { z } from "zod";
import { openAndVerify, sealAndSign } from "../crypto/envelope.js";
import { computeSAS } from "../crypto/sas.js";
import type { Identity } from "../crypto/identity.js";
import type { SodiumBackend } from "../crypto/backend.js";
import { fromHex, fromUtf8, toHex, utf8 } from "../encoding.js";
import { AckPayload, RequestPayload } from "../protocol/messages.js";
import type { CapabilityRegistry, Risk } from "../protocol/registry.js";
import { PROTOCOL_VERSION, isSupportedVersion } from "../protocol/version.js";
import {
	decodeFrame,
	encodeFrame,
	type PairRequest,
} from "../protocol/wire.js";
import type { PairingOffer } from "../protocol/pairing.js";
import type { AntiReplay } from "./anti-replay.js";
import type { AuditLog } from "./audit.js";

export interface PairedPeer {
	signPub: Uint8Array;
	boxPub: Uint8Array;
	permissions: Set<string>;
}

export type HostHandlers = Record<string, (params: unknown) => unknown>;

export interface ReferenceHostOptions {
	backend: SodiumBackend;
	identity: Identity;
	registry: CapabilityRegistry;
	antiReplay: AntiReplay;
	audit: AuditLog;
	handlers: HostHandlers;
	grantedPermissions?: string[];
	pairingTokenTtlMs?: number;
	now?: () => number;
}

export class ReferenceHost {
	killSwitch = false;
	lastSas: string | null = null;

	private readonly backend: SodiumBackend;
	private readonly identity: Identity;
	private readonly registry: CapabilityRegistry;
	private readonly antiReplay: AntiReplay;
	private readonly audit: AuditLog;
	private readonly handlers: HostHandlers;
	private readonly grantedPermissions: string[];
	private readonly pairingTokenTtlMs: number;
	private readonly now: () => number;

	private pendingToken: string | null = null;
	private pendingTokenExpiresAt: number | null = null;
	private pendingPeer: PairedPeer | null = null;
	private peer: PairedPeer | null = null;

	constructor(options: ReferenceHostOptions) {
		this.backend = options.backend;
		this.identity = options.identity;
		this.registry = options.registry;
		this.antiReplay = options.antiReplay;
		this.audit = options.audit;
		this.handlers = options.handlers;
		this.grantedPermissions = options.grantedPermissions ?? ["hello:invoke"];
		this.pairingTokenTtlMs = options.pairingTokenTtlMs ?? 120_000;
		this.now = options.now ?? (() => Date.now());
	}

	get isPaired(): boolean {
		return this.peer !== null;
	}

	activePeer(): { signPub: Uint8Array; boxPub: Uint8Array } | null {
		return this.peer ? { signPub: this.peer.signPub, boxPub: this.peer.boxPub } : null;
	}

	createPairingOffer(
		connect: { urls: [string, ...string[]] } = { urls: ["memory://local"] },
	): PairingOffer {
		this.pendingToken = toHex(this.backend.randomBytes(16));
		this.pendingTokenExpiresAt = this.now() + this.pairingTokenTtlMs;
		return {
			token: this.pendingToken,
			signPubHex: toHex(this.identity.sign.publicKey),
			boxPubHex: toHex(this.identity.box.publicKey),
			connect,
			expiresAt: this.pendingTokenExpiresAt,
		};
	}

	handle(frameBytes: Uint8Array): Uint8Array | null {
		const frame = decodeFrame(frameBytes);
		if (!frame) {
			this.reject(null, null, "malformed-frame");
			return null;
		}
		if (frame.t === "pair-request") {
			return this.acceptPairing(frame);
		}
		if (frame.t === "sealed") {
			return this.handleSealed(frame.boxHex);
		}
		if (frame.t === "addressed") {
			// Peer-layer traffic; an embedded Peer owns it. Ignore without auditing so
			// the legacy hello path and the Peer can share one transport.
			return null;
		}
		this.reject(null, null, "unexpected-frame");
		return null;
	}

	private acceptPairing(frame: z.infer<typeof PairRequest>): Uint8Array | null {
		if (!this.pendingToken || frame.token !== this.pendingToken) {
			this.reject(null, null, "bad-pairing-token");
			return null;
		}
		if (
			this.pendingTokenExpiresAt === null ||
			this.now() > this.pendingTokenExpiresAt
		) {
			this.pendingToken = null;
			this.pendingTokenExpiresAt = null;
			this.reject(null, null, "pairing-token-expired");
			return null;
		}
		this.pendingTokenExpiresAt = null;
		this.pendingToken = null;
		const peerSignPub = fromHex(frame.clientSignPubHex);
		const peerBoxPub = fromHex(frame.clientBoxPubHex);
		// Hold the peer keys as PENDING. They are only stored as the active peer
		// once the operator confirms the SAS via confirmPairing(true).
		this.pendingPeer = {
			signPub: peerSignPub,
			boxPub: peerBoxPub,
			permissions: new Set(this.grantedPermissions),
		};
		this.lastSas = computeSAS(
			this.backend,
			this.identity.sign.publicKey,
			this.identity.box.publicKey,
			peerSignPub,
			peerBoxPub,
		);
		return encodeFrame({
			t: "pair-accept",
			v: PROTOCOL_VERSION,
			hostSignPubHex: toHex(this.identity.sign.publicKey),
			hostBoxPubHex: toHex(this.identity.box.publicKey),
		});
	}

	confirmPairing(confirmed: boolean): boolean {
		if (!this.pendingPeer) {
			this.reject("pairing", null, "no-pending-pairing");
			return false;
		}
		if (!confirmed) {
			this.pendingPeer = null;
			this.reject("pairing", null, "sas-mismatch");
			return false;
		}
		this.peer = this.pendingPeer;
		this.pendingPeer = null;
		this.audit.append({ cap: "pairing", risk: null, outcome: "accepted" });
		return true;
	}

	private handleSealed(boxHex: string): Uint8Array | null {
		if (this.killSwitch) {
			this.reject(null, null, "kill-switch");
			return null;
		}
		if (!this.peer) {
			this.reject(null, null, "not-paired");
			return null;
		}

		const opened = openAndVerify(
			this.backend,
			fromHex(boxHex),
			this.identity.box.publicKey,
			this.identity.box.privateKey,
			this.peer.signPub,
		);
		if (!opened.ok) {
			this.reject(null, null, opened.reason);
			return null;
		}

		let payload: RequestPayload;
		try {
			const parsed = RequestPayload.safeParse(
				JSON.parse(fromUtf8(opened.payloadBytes)),
			);
			if (!parsed.success) {
				this.reject(null, null, "malformed-payload");
				return null;
			}
			payload = parsed.data;
		} catch {
			this.reject(null, null, "malformed-payload");
			return null;
		}

		if (!isSupportedVersion(payload.v)) {
			this.reject(payload.cap, null, "unsupported-version");
			return null;
		}

		const replay = this.antiReplay.check(payload.nonce, payload.ts);
		if (!replay.ok) {
			this.reject(payload.cap, null, replay.reason ?? "replay");
			return null;
		}

		const def = this.registry.get(payload.cap);
		if (!def) {
			this.reject(payload.cap, null, "unknown-capability");
			return null;
		}

		const schemaResult = def.schema.safeParse(payload.params);
		if (!schemaResult.success) {
			this.reject(payload.cap, def.risk, "schema-invalid");
			return null;
		}

		if (!this.peer.permissions.has(def.permission)) {
			this.reject(payload.cap, def.risk, "permission-denied");
			return null;
		}

		const handler = this.handlers[payload.cap];
		if (!handler) {
			this.reject(payload.cap, def.risk, "no-handler");
			return null;
		}

		const result = handler(schemaResult.data);
		this.audit.append({
			cap: payload.cap,
			risk: def.risk,
			outcome: "accepted",
		});
		return this.buildAck(payload.cap, result);
	}

	private buildAck(cap: string, result: unknown): Uint8Array {
		const ack: AckPayload = {
			v: PROTOCOL_VERSION,
			ok: true,
			cap,
			result,
			nonce: toHex(this.backend.randomBytes(16)),
			ts: this.now(),
		};
		const sealed = sealAndSign(
			this.backend,
			utf8(JSON.stringify(ack)),
			this.identity.sign.privateKey,
			this.peer!.boxPub,
		);
		return encodeFrame({
			t: "sealed",
			v: PROTOCOL_VERSION,
			boxHex: toHex(sealed),
		});
	}

	private reject(cap: string | null, risk: Risk | null, reason: string): void {
		this.audit.append({ cap, risk, outcome: "rejected", reason });
	}
}
