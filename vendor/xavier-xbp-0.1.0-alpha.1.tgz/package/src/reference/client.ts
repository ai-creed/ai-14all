import type { SodiumBackend } from "../crypto/backend.js";
import { openAndVerify, sealAndSign } from "../crypto/envelope.js";
import type { Identity } from "../crypto/identity.js";
import { fromHex, fromUtf8, toHex, utf8 } from "../encoding.js";
import { AckPayload } from "../protocol/messages.js";
import { PROTOCOL_VERSION } from "../protocol/version.js";
import { decodeFrame, encodeFrame, type PairAccept } from "../protocol/wire.js";
import { computeSAS } from "../crypto/sas.js";
import type { z } from "zod";

export interface ReferenceClientOptions {
	backend: SodiumBackend;
	identity: Identity;
	now?: () => number;
}

export interface RequestOptions {
	nonce?: string;
	version?: string;
	omitVersion?: boolean;
	ts?: number;
	signPrivateKeyOverride?: Uint8Array;
	recipientBoxPubOverride?: Uint8Array;
	tamper?: boolean;
}

export class ReferenceClient {
	private readonly backend: SodiumBackend;
	private readonly identity: Identity;
	private readonly now: () => number;
	private hostSignPub: Uint8Array | null = null;
	private hostBoxPub: Uint8Array | null = null;
	private pendingHostSignPub: Uint8Array | null = null;
	private pendingHostBoxPub: Uint8Array | null = null;

	constructor(options: ReferenceClientOptions) {
		this.backend = options.backend;
		this.identity = options.identity;
		this.now = options.now ?? (() => Date.now());
	}

	buildPairRequest(token: string): Uint8Array {
		return encodeFrame({
			t: "pair-request",
			v: PROTOCOL_VERSION,
			token,
			clientSignPubHex: toHex(this.identity.sign.publicKey),
			clientBoxPubHex: toHex(this.identity.box.publicKey),
		});
	}

	acceptPairResponse(
		frame: z.infer<typeof PairAccept>,
		offer: { signPubHex: string; boxPubHex: string },
	): string {
		// Hold the host keys as PENDING; bind the SAS to the host sign key from the
		// accept frame and the host box key from the out-of-band offer. They become
		// active only once confirmPairing(true) is called after an SAS match.
		this.pendingHostSignPub = fromHex(frame.hostSignPubHex);
		this.pendingHostBoxPub = fromHex(offer.boxPubHex);
		return computeSAS(
			this.backend,
			this.identity.sign.publicKey,
			this.identity.box.publicKey,
			this.pendingHostSignPub,
			this.pendingHostBoxPub,
		);
	}

	confirmPairing(confirmed: boolean): boolean {
		if (!this.pendingHostSignPub || !this.pendingHostBoxPub) {
			return false;
		}
		if (!confirmed) {
			this.pendingHostSignPub = null;
			this.pendingHostBoxPub = null;
			return false;
		}
		this.hostSignPub = this.pendingHostSignPub;
		this.hostBoxPub = this.pendingHostBoxPub;
		this.pendingHostSignPub = null;
		this.pendingHostBoxPub = null;
		return true;
	}

	buildRequest(
		cap: string,
		params: unknown,
		opts: RequestOptions = {},
	): Uint8Array {
		if (!this.hostBoxPub) {
			throw new Error("client is not paired");
		}
		const payload: Record<string, unknown> = {
			cap,
			params,
			nonce: opts.nonce ?? toHex(this.backend.randomBytes(16)),
			ts: opts.ts ?? this.now(),
		};
		if (!opts.omitVersion) {
			payload.v = opts.version ?? PROTOCOL_VERSION;
		}
		const signPrivate =
			opts.signPrivateKeyOverride ?? this.identity.sign.privateKey;
		const recipient = opts.recipientBoxPubOverride ?? this.hostBoxPub;
		let sealed = sealAndSign(
			this.backend,
			utf8(JSON.stringify(payload)),
			signPrivate,
			recipient,
		);
		if (opts.tamper) {
			sealed = sealed.slice();
			sealed[0] ^= 0xff;
		}
		return encodeFrame({
			t: "sealed",
			v: PROTOCOL_VERSION,
			boxHex: toHex(sealed),
		});
	}

	openAck(frameBytes: Uint8Array): AckPayload | null {
		if (!this.hostSignPub) {
			return null;
		}
		const frame = decodeFrame(frameBytes);
		if (!frame || frame.t !== "sealed") {
			return null;
		}
		const opened = openAndVerify(
			this.backend,
			fromHex(frame.boxHex),
			this.identity.box.publicKey,
			this.identity.box.privateKey,
			this.hostSignPub,
		);
		if (!opened.ok) {
			return null;
		}
		const parsed = AckPayload.safeParse(
			JSON.parse(fromUtf8(opened.payloadBytes)),
		);
		return parsed.success ? parsed.data : null;
	}
}
