import { z, type ZodType } from "zod";

export type Risk = "low" | "medium" | "high";
export type Permission = string;

export interface CapabilityDefinition<T = unknown> {
	id: string;
	schema: ZodType<T>;
	risk: Risk;
	permission: Permission;
}

const RISKS: readonly Risk[] = ["low", "medium", "high"];

export function defineCapability<T>(
	def: CapabilityDefinition<T>,
): CapabilityDefinition<T> {
	if (!def || typeof def.id !== "string" || def.id.length === 0) {
		throw new Error("capability: missing id");
	}
	if (!def.schema || typeof def.schema.safeParse !== "function") {
		throw new Error(`capability ${def.id}: missing schema`);
	}
	if (!RISKS.includes(def.risk)) {
		throw new Error(`capability ${def.id}: missing or invalid risk`);
	}
	if (typeof def.permission !== "string" || def.permission.length === 0) {
		throw new Error(`capability ${def.id}: missing permission`);
	}
	return def;
}

export class CapabilityRegistry {
	private readonly map = new Map<string, CapabilityDefinition>();

	register(def: CapabilityDefinition): void {
		const validated = defineCapability(def);
		this.map.set(validated.id, validated);
	}

	get(id: string): CapabilityDefinition | undefined {
		return this.map.get(id);
	}

	has(id: string): boolean {
		return this.map.has(id);
	}
}

export const helloCapability = defineCapability({
	id: "hello",
	schema: z.object({ greeting: z.string() }),
	risk: "low",
	permission: "hello:invoke",
});
