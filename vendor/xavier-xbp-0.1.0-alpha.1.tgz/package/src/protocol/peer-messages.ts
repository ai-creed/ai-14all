import { z } from "zod";

// Messages carried INSIDE the sealed envelope (itself wrapped by the addressed
// frame). nonce + ts drive anti-replay exactly as the legacy RequestPayload did;
// kind + requestId add request/ack correlation and a fire-and-forget event
// shape — the two pieces the symmetric Peer needs.
export const RequestMessage = z.object({
	v: z.string(),
	kind: z.literal("request"),
	requestId: z.string(),
	capabilityId: z.string(),
	args: z.unknown(),
	nonce: z.string(),
	ts: z.number(),
});
export type RequestMessage = z.infer<typeof RequestMessage>;

// The ack is the spec's discriminated union: an ok ack carries a result (no
// error); an error ack carries {code, message} (no result). Modelling it as a
// union on `ok` makes malformed acks fail closed — {ok:false} with no error and
// {ok:true} with no result both fail validation, instead of silently passing.
const AckOk = z.object({
	v: z.string(),
	kind: z.literal("ack"),
	requestId: z.string(),
	ok: z.literal(true),
	// Required + non-undefined: an ok ack must carry a result. The refine makes
	// the field required (an absent or undefined result fails). Slice 1's
	// capabilities always return a structured value, so there are no void acks.
	result: z.unknown().refine((value) => value !== undefined, {
		message: "an ok ack requires a result",
	}),
	nonce: z.string(),
	ts: z.number(),
});
const AckError = z.object({
	v: z.string(),
	kind: z.literal("ack"),
	requestId: z.string(),
	ok: z.literal(false),
	error: z.object({ code: z.string(), message: z.string() }),
	nonce: z.string(),
	ts: z.number(),
});
export const AckMessage = z.discriminatedUnion("ok", [AckOk, AckError]);
export type AckMessage = z.infer<typeof AckMessage>;

export const EventMessage = z.object({
	v: z.string(),
	kind: z.literal("event"),
	topic: z.string(),
	payload: z.unknown(),
	nonce: z.string(),
	ts: z.number(),
});
export type EventMessage = z.infer<typeof EventMessage>;

// A plain union (not discriminatedUnion on "kind") because AckMessage is itself
// a union; each member's literal `kind`/`ok` keeps parsing unambiguous and keeps
// malformed acks failing closed.
export const PeerMessage = z.union([RequestMessage, AckMessage, EventMessage]);
export type PeerMessage = z.infer<typeof PeerMessage>;
