import { z } from "zod";

export const RequestPayload = z.object({
	v: z.string(),
	cap: z.string(),
	params: z.unknown(),
	nonce: z.string(),
	ts: z.number(),
});
export type RequestPayload = z.infer<typeof RequestPayload>;

export const AckPayload = z.object({
	v: z.string(),
	ok: z.boolean(),
	cap: z.string(),
	result: z.unknown().optional(),
	nonce: z.string(),
	ts: z.number(),
});
export type AckPayload = z.infer<typeof AckPayload>;
