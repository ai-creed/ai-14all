import { z } from "zod";
import { toHex } from "../encoding.js";
import type { SodiumBackend } from "../crypto/backend.js";

// Host <-> relay rendezvous control channel (JSON text frames). These frames
// carry no secrets — the sealed session never rides the control channel — and
// there is deliberately NO error message shape: every failure is answered by
// closing the socket with one of the codes below and nothing else (spec §3.2).
export const RELAY_CLOSE_PROTOCOL_VIOLATION = 4400;
export const RELAY_CLOSE_BAD_AUTH = 4401;
export const RELAY_CLOSE_HOST_NOT_REGISTERED = 4404;
export const RELAY_CLOSE_ACCEPT_TIMEOUT = 4408;

// Hex fields are length-pinned at the schema so malformed cryptographic input
// fails PARSE — and therefore closes 4400 — before any crypto runs: libsodium
// THROWS on wrong-length keys/signatures instead of returning false, and the
// verify path must never be reachable with unvalidated lengths.
const signPubHex = z.string().regex(/^[0-9a-f]{64}$/); // 32-byte ed25519 pubkey
const sigHex = z.string().regex(/^[0-9a-f]{128}$/); // 64-byte detached signature
const nonceHex = z.string().regex(/^[0-9a-f]{64}$/); // 32-byte nonce
const hostIdHex = z.string().regex(/^[0-9a-f]{64}$/); // 32-byte hash
const tokenHex = z.string().regex(/^[0-9a-f]{32}$/); // 16-byte accept token

const RelayRegister = z.object({ t: z.literal("register"), signPubHex });
const RelayChallengeResponse = z.object({ t: z.literal("challenge-response"), sigHex });
const RelayChallenge = z.object({ t: z.literal("challenge"), nonceHex });
const RelayRegistered = z.object({ t: z.literal("registered"), hostId: hostIdHex });
const RelayIncomingSession = z.object({ t: z.literal("incoming-session"), token: tokenHex });

export const RelayHostSent = z.discriminatedUnion("t", [RelayRegister, RelayChallengeResponse]);
export type RelayHostSent = z.infer<typeof RelayHostSent>;

export const RelayHostBound = z.discriminatedUnion("t", [
	RelayChallenge,
	RelayRegistered,
	RelayIncomingSession,
]);
export type RelayHostBound = z.infer<typeof RelayHostBound>;

function parseJson(text: string): unknown | undefined {
	try {
		return JSON.parse(text);
	} catch {
		return undefined;
	}
}

export function parseRelayHostSent(text: string): RelayHostSent | null {
	const parsed = RelayHostSent.safeParse(parseJson(text));
	return parsed.success ? parsed.data : null;
}

export function parseRelayHostBound(text: string): RelayHostBound | null {
	const parsed = RelayHostBound.safeParse(parseJson(text));
	return parsed.success ? parsed.data : null;
}

// hostId = hex(BLAKE2b-256(sign pubkey)) via the backend's generichash. The
// relay computes it from the pubkey presented at registration; the host
// computes the same value to build its advertised /connect/<hostId> URL.
export function deriveHostId(
	backend: Pick<SodiumBackend, "hash">,
	signPub: Uint8Array,
): string {
	return toHex(backend.hash(signPub, 32));
}
