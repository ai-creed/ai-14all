export const PROTOCOL_VERSION = "xbp/1";

export function isSupportedVersion(
	value: unknown,
): value is typeof PROTOCOL_VERSION {
	return value === PROTOCOL_VERSION;
}
