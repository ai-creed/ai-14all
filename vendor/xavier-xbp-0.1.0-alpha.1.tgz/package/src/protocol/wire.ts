import { z } from "zod";
import { fromUtf8, utf8 } from "../encoding.js";
import { PROTOCOL_VERSION } from "./version.js";

// Every wire frame carries the protocol version; an absent or mismatched
// version fails schema validation, so unversioned frames are invalid.
export const PairRequest = z.object({
	t: z.literal("pair-request"),
	v: z.literal(PROTOCOL_VERSION),
	token: z.string(),
	clientSignPubHex: z.string(),
	clientBoxPubHex: z.string(),
});

export const PairAccept = z.object({
	t: z.literal("pair-accept"),
	v: z.literal(PROTOCOL_VERSION),
	hostSignPubHex: z.string(),
	hostBoxPubHex: z.string(),
});

export const SealedFrame = z.object({
	t: z.literal("sealed"),
	v: z.literal(PROTOCOL_VERSION),
	boxHex: z.string(),
});

export const AddressedFrame = z.object({
	t: z.literal("addressed"),
	v: z.literal(PROTOCOL_VERSION),
	to: z.string(),
	from: z.string(),
	// The spec's `{to, from, payload}` wrapper field: the sealed-envelope bytes,
	// hex-encoded for the JSON wire (same convention as SealedFrame.boxHex). The
	// header is advisory — trust lives in the inner seal — so a blind relay reads
	// `to`/`from` and forwards `payload` without ever opening it.
	payload: z.string(),
});

export const WireFrame = z.discriminatedUnion("t", [
	PairRequest,
	PairAccept,
	SealedFrame,
	AddressedFrame,
]);
export type WireFrame = z.infer<typeof WireFrame>;

export function encodeFrame(frame: WireFrame): Uint8Array {
	return utf8(JSON.stringify(frame));
}

export function decodeFrame(bytes: Uint8Array): WireFrame | null {
	try {
		const parsed = WireFrame.safeParse(JSON.parse(fromUtf8(bytes)));
		return parsed.success ? parsed.data : null;
	} catch {
		return null;
	}
}
