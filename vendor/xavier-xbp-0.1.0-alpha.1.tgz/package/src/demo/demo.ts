import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { pathToFileURL } from "node:url";
import {
	AntiReplay,
	type AuditEntry,
	AuditLog,
	CapabilityRegistry,
	connectWebSocketClient,
	createNodeSodiumBackend,
	decodeFrame,
	generateIdentity,
	helloCapability,
	PairAccept,
	ReferenceClient,
	ReferenceHost,
	requestOnce,
	serveHost,
	type SodiumBackend,
	startWebSocketHost,
	type Transport,
} from "../index.node.js";

export interface DemoStep {
	name: string;
	outcome: "accepted" | "rejected";
	reason?: string;
}

export interface DemoSummary {
	sas: { host: string; client: string; match: boolean };
	steps: DemoStep[];
	audit: AuditEntry[];
}

interface RunDemoOptions {
	hostTransport: Transport;
	clientTransport: Transport;
	backend: SodiumBackend;
	auditPath: string;
	log?: (message: string) => void;
}

async function waitForNewAudit(
	audit: AuditLog,
	beforeCount: number,
	timeoutMs = 2000,
): Promise<AuditEntry> {
	const start = Date.now();
	while (Date.now() - start < timeoutMs) {
		const entries = audit.entries();
		if (entries.length > beforeCount) {
			return entries[entries.length - 1];
		}
		await new Promise((resolve) => setTimeout(resolve, 5));
	}
	throw new Error("waitForNewAudit: no entry produced");
}

export async function runDemo(options: RunDemoOptions): Promise<DemoSummary> {
	const log = options.log ?? (() => {});
	const { backend, hostTransport, clientTransport } = options;

	const registry = new CapabilityRegistry();
	registry.register(helloCapability);
	const audit = new AuditLog(options.auditPath);

	const host = new ReferenceHost({
		backend,
		identity: generateIdentity(backend),
		registry,
		antiReplay: new AntiReplay(),
		audit,
		handlers: {
			hello: (params) => ({
				youSaid: (params as { greeting: string }).greeting,
			}),
		},
	});
	const client = new ReferenceClient({
		backend,
		identity: generateIdentity(backend),
	});

	serveHost(host, hostTransport);

	log("== Pairing ==");
	const offer = host.createPairingOffer();
	const acceptBytes = await requestOnce(
		clientTransport,
		client.buildPairRequest(offer.token),
	);
	const accept = PairAccept.parse(decodeFrame(acceptBytes));
	const clientSas = client.acceptPairResponse(accept, offer);
	const hostSas = host.lastSas as string;
	const match = hostSas === clientSas;
	// The operator compares the two SAS strings and confirms; only then are keys stored.
	host.confirmPairing(match);
	client.confirmPairing(match);
	log(
		`SAS host=${hostSas} client=${clientSas} match=${match} paired=${host.isPaired}`,
	);

	const steps: DemoStep[] = [];

	log("== Happy path: hello ==");
	const helloAck = await requestOnce(
		clientTransport,
		client.buildRequest("hello", { greeting: "hi" }),
	);
	const helloOk = decodeFrame(helloAck)?.t === "sealed";
	steps.push({ name: "hello", outcome: helloOk ? "accepted" : "rejected" });
	log(`hello -> ${helloOk ? "accepted" : "rejected"}`);

	for (const attack of [
		{
			name: "tamper",
			frame: () =>
				client.buildRequest("hello", { greeting: "hi" }, { tamper: true }),
		},
		{
			name: "forge",
			frame: () =>
				client.buildRequest(
					"hello",
					{ greeting: "hi" },
					{
						signPrivateKeyOverride: backend.generateSignKeyPair().privateKey,
					},
				),
		},
	]) {
		const before = audit.entries().length;
		await clientTransport.send(attack.frame());
		const entry = await waitForNewAudit(audit, before);
		steps.push({
			name: attack.name,
			outcome: entry.outcome,
			reason: entry.reason,
		});
		log(`${attack.name} -> ${entry.outcome} (${entry.reason})`);
	}

	log("== Replay ==");
	await requestOnce(
		clientTransport,
		client.buildRequest("hello", { greeting: "hi" }, { nonce: "replay-nonce" }),
	);
	const replayBefore = audit.entries().length;
	await clientTransport.send(
		client.buildRequest("hello", { greeting: "hi" }, { nonce: "replay-nonce" }),
	);
	const replayEntry = await waitForNewAudit(audit, replayBefore);
	steps.push({
		name: "replay",
		outcome: replayEntry.outcome,
		reason: replayEntry.reason,
	});
	log(`replay -> ${replayEntry.outcome} (${replayEntry.reason})`);

	log("== Kill switch ==");
	host.killSwitch = true;
	const killBefore = audit.entries().length;
	await clientTransport.send(client.buildRequest("hello", { greeting: "hi" }));
	const killEntry = await waitForNewAudit(audit, killBefore);
	steps.push({
		name: "kill-switch",
		outcome: killEntry.outcome,
		reason: killEntry.reason,
	});
	log(`kill-switch -> ${killEntry.outcome} (${killEntry.reason})`);

	return {
		sas: { host: hostSas, client: clientSas, match },
		steps,
		audit: audit.entries(),
	};
}

async function main(): Promise<void> {
	const backend = await createNodeSodiumBackend();
	const wsHost = await startWebSocketHost(0);
	const connectionPromise = wsHost.nextConnection();
	const clientTransport = await connectWebSocketClient(
		`ws://127.0.0.1:${wsHost.port}`,
	);
	const hostTransport = await connectionPromise;
	const auditPath = join(
		mkdtempSync(join(tmpdir(), "xbp-demo-")),
		"audit.jsonl",
	);

	const summary = await runDemo({
		hostTransport,
		clientTransport,
		backend,
		auditPath,
		log: (message) => console.log(message),
	});

	console.log("\n== Audit ==");
	for (const entry of summary.audit) {
		console.log(`  ${JSON.stringify(entry)}`);
	}

	await clientTransport.close();
	await hostTransport.close();
	await wsHost.close();
}

if (
	process.argv[1] &&
	import.meta.url === pathToFileURL(process.argv[1]).href
) {
	void main();
}
