import assert from "node:assert/strict";
import { z } from "zod";
import {
	type AckPayload,
	type AuditEntry,
	defineCapability,
	type RequestOptions,
	type SodiumBackend,
} from "../index.node.js";

export interface PairOutcome {
	hostSas: string;
	clientSas: string;
	paired: boolean;
}

export interface ConformanceHarness {
	backend: SodiumBackend;
	pair(): PairOutcome;
	pairWithSubstitutedKey(): PairOutcome;
	send(
		cap: string,
		params: unknown,
		opts?: RequestOptions,
	): { ack: AckPayload | null; reason?: string };
	sendRawFrame(frame: Uint8Array): { ack: AckPayload | null; reason?: string };
	setKillSwitch(on: boolean): void;
	auditEntries(): AuditEntry[];
}

export type HarnessFactory = (opts?: {
	grantedPermissions?: string[];
}) => Promise<ConformanceHarness>;

export const conformanceChecks: {
	name: string;
	run: (make: HarnessFactory) => Promise<void>;
}[] = [
	{
		name: "envelope round-trip succeeds",
		run: async (make) => {
			const h = await make();
			h.pair();
			const { ack } = h.send("hello", { greeting: "hi" });
			assert.equal(ack?.ok, true);
			assert.equal(ack?.cap, "hello");
		},
	},
	{
		name: "tampered ciphertext rejected",
		run: async (make) => {
			const h = await make();
			h.pair();
			const { ack, reason } = h.send(
				"hello",
				{ greeting: "hi" },
				{ tamper: true },
			);
			assert.equal(ack, null);
			assert.equal(reason, "decrypt-failed");
		},
	},
	{
		name: "forged signature rejected",
		run: async (make) => {
			const h = await make();
			h.pair();
			const wrong = h.backend.generateSignKeyPair();
			const { ack, reason } = h.send(
				"hello",
				{ greeting: "hi" },
				{
					signPrivateKeyOverride: wrong.privateKey,
				},
			);
			assert.equal(ack, null);
			assert.equal(reason, "bad-signature");
		},
	},
	{
		name: "wrong-recipient envelope rejected",
		run: async (make) => {
			const h = await make();
			h.pair();
			const stranger = h.backend.generateBoxKeyPair();
			const { ack, reason } = h.send(
				"hello",
				{ greeting: "hi" },
				{
					recipientBoxPubOverride: stranger.publicKey,
				},
			);
			assert.equal(ack, null);
			assert.equal(reason, "decrypt-failed");
		},
	},
	{
		name: "pairing succeeds with a matching SAS",
		run: async (make) => {
			const h = await make();
			const { hostSas, clientSas, paired } = h.pair();
			assert.equal(hostSas, clientSas);
			assert.equal(paired, true);
		},
	},
	{
		name: "SAS mismatch is rejected and stores no peer",
		run: async (make) => {
			const h = await make();
			const { hostSas, clientSas, paired } = h.pairWithSubstitutedKey();
			assert.notEqual(hostSas, clientSas);
			assert.equal(paired, false);
		},
	},
	{
		name: "pairing decisions are audited",
		run: async (make) => {
			const ok = await make();
			const okBefore = ok.auditEntries().length;
			ok.pair();
			const okEntries = ok.auditEntries();
			assert.equal(okEntries.length, okBefore + 1);
			assert.equal(okEntries[okEntries.length - 1].cap, "pairing");
			assert.equal(okEntries[okEntries.length - 1].outcome, "accepted");

			const bad = await make();
			const badBefore = bad.auditEntries().length;
			bad.pairWithSubstitutedKey();
			const badEntries = bad.auditEntries();
			assert.equal(badEntries.length, badBefore + 1);
			assert.equal(badEntries[badEntries.length - 1].outcome, "rejected");
			assert.equal(badEntries[badEntries.length - 1].reason, "sas-mismatch");
		},
	},
	{
		name: "unversioned wire frame rejected",
		run: async (make) => {
			const h = await make();
			h.pair();
			const unversioned = new TextEncoder().encode(
				JSON.stringify({ t: "sealed", boxHex: "00" }),
			);
			const { ack, reason } = h.sendRawFrame(unversioned);
			assert.equal(ack, null);
			assert.equal(reason, "malformed-frame");
		},
	},
	{
		name: "replayed nonce rejected",
		run: async (make) => {
			const h = await make();
			h.pair();
			h.send("hello", { greeting: "hi" }, { nonce: "fixed" });
			const { ack, reason } = h.send(
				"hello",
				{ greeting: "hi" },
				{ nonce: "fixed" },
			);
			assert.equal(ack, null);
			assert.equal(reason, "nonce-reused");
		},
	},
	{
		name: "stale timestamp rejected",
		run: async (make) => {
			const h = await make();
			h.pair();
			const { ack, reason } = h.send("hello", { greeting: "hi" }, { ts: 1 });
			assert.equal(ack, null);
			assert.equal(reason, "stale-timestamp");
		},
	},
	{
		name: "unsupported protocol version rejected",
		run: async (make) => {
			const h = await make();
			h.pair();
			const { ack, reason } = h.send(
				"hello",
				{ greeting: "hi" },
				{ version: "xbp/0" },
			);
			assert.equal(ack, null);
			assert.equal(reason, "unsupported-version");
		},
	},
	{
		name: "absent protocol version rejected",
		run: async (make) => {
			const h = await make();
			h.pair();
			const { ack } = h.send(
				"hello",
				{ greeting: "hi" },
				{ omitVersion: true },
			);
			assert.equal(ack, null);
		},
	},
	{
		name: "capability definitions require schema, risk, and permission",
		run: async () => {
			assert.throws(
				() =>
					defineCapability({ id: "x", risk: "low", permission: "p" } as never),
				/schema/,
			);
			assert.throws(
				() =>
					defineCapability({
						id: "x",
						schema: z.object({}),
						permission: "p",
					} as never),
				/risk/,
			);
			assert.throws(
				() =>
					defineCapability({
						id: "x",
						schema: z.object({}),
						risk: "low",
					} as never),
				/permission/,
			);
		},
	},
	{
		name: "accepted request records capability risk in the audit",
		run: async (make) => {
			const h = await make();
			h.pair();
			h.send("hello", { greeting: "hi" });
			const accepted = h
				.auditEntries()
				.filter((entry) => entry.outcome === "accepted")
				.at(-1);
			assert.equal(accepted?.risk, "low");
		},
	},
	{
		name: "insufficient permission rejected",
		run: async (make) => {
			const h = await make({ grantedPermissions: [] });
			h.pair();
			const { ack, reason } = h.send("hello", { greeting: "hi" });
			assert.equal(ack, null);
			assert.equal(reason, "permission-denied");
		},
	},
	{
		name: "unknown capability rejected",
		run: async (make) => {
			const h = await make();
			h.pair();
			const { ack, reason } = h.send("ghost", {});
			assert.equal(ack, null);
			assert.equal(reason, "unknown-capability");
		},
	},
	{
		name: "schema-invalid request rejected",
		run: async (make) => {
			const h = await make();
			h.pair();
			const { ack, reason } = h.send("hello", { greeting: 123 });
			assert.equal(ack, null);
			assert.equal(reason, "schema-invalid");
		},
	},
	{
		name: "writes exactly one matching audit entry per decision",
		run: async (make) => {
			const h = await make();
			h.pair();
			let expected = h.auditEntries().length;
			const step = (outcome: "accepted" | "rejected", reason?: string) => {
				expected += 1;
				const entries = h.auditEntries();
				assert.equal(
					entries.length,
					expected,
					`expected ${expected} audit entries`,
				);
				const last = entries[entries.length - 1];
				assert.equal(last.outcome, outcome);
				if (reason !== undefined) {
					assert.equal(last.reason, reason);
				}
			};

			h.send("hello", { greeting: "hi" });
			step("accepted");
			h.send("hello", { greeting: "hi" }, { tamper: true });
			step("rejected", "decrypt-failed");
			h.send(
				"hello",
				{ greeting: "hi" },
				{
					signPrivateKeyOverride: h.backend.generateSignKeyPair().privateKey,
				},
			);
			step("rejected", "bad-signature");
			h.send(
				"hello",
				{ greeting: "hi" },
				{
					recipientBoxPubOverride: h.backend.generateBoxKeyPair().publicKey,
				},
			);
			step("rejected", "decrypt-failed");
			h.send("ghost", {});
			step("rejected", "unknown-capability");
			h.send("hello", { greeting: 123 });
			step("rejected", "schema-invalid");
			h.send("hello", { greeting: "hi" }, { version: "xbp/0" });
			step("rejected", "unsupported-version");
			h.send("hello", { greeting: "hi" }, { ts: 1 });
			step("rejected", "stale-timestamp");
			h.send("hello", { greeting: "hi" }, { nonce: "audit-replay" });
			step("accepted");
			h.send("hello", { greeting: "hi" }, { nonce: "audit-replay" });
			step("rejected", "nonce-reused");
			h.setKillSwitch(true);
			h.send("hello", { greeting: "hi" });
			step("rejected", "kill-switch");
		},
	},
	{
		name: "kill switch halts processing",
		run: async (make) => {
			const h = await make();
			h.pair();
			h.setKillSwitch(true);
			const { ack, reason } = h.send("hello", { greeting: "hi" });
			assert.equal(ack, null);
			assert.equal(reason, "kill-switch");
		},
	},
];

// Re-export the types harness authors need so a downstream consumer needs only
// the one `@xavier/xbp/conformance` import.
export type { AckPayload, AuditEntry, RequestOptions } from "../index.node.js";
