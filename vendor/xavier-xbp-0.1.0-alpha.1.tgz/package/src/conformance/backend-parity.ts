import type { SodiumBackend } from "../crypto/backend.js";
import { openAndVerify, sealAndSign } from "../crypto/envelope.js";
import { computeSAS } from "../crypto/sas.js";
import { fromHex, toHex, utf8 } from "../encoding.js";
import {
	assertEqual,
	assertEqualBytes,
	assertNotEqual,
	assertNull,
	assertOk,
} from "./assert.js";
import { PARITY_VECTORS as V } from "./vectors.js";

export interface ParityCheck {
	name: string;
	run: (backend: SodiumBackend) => void;
}

// The contract a SodiumBackend must honor, plus known-answer interoperability
// with the Node (libsodium) backend. Runner-agnostic: each `run` throws on
// failure. The Node adapter runs these in CI; the phone runs the identical list
// on-device against RnSodiumBackend.
export const backendParityChecks: ParityCheck[] = [
	{
		name: "seal/open round-trips",
		run: (backend) => {
			const box = backend.generateBoxKeyPair();
			const message = utf8("round-trip");
			const sealed = backend.seal(message, box.publicKey);
			const opened = backend.open(sealed, box.publicKey, box.privateKey);
			assertOk(opened !== null, "open returned null on a valid sealed box");
			assertEqualBytes(opened!, message, "opened plaintext mismatch");
		},
	},
	{
		name: "open returns null on tampered ciphertext",
		run: (backend) => {
			const box = backend.generateBoxKeyPair();
			const sealed = backend.seal(utf8("x"), box.publicKey);
			const tampered = sealed.slice();
			tampered[0] ^= 0xff;
			assertNull(
				backend.open(tampered, box.publicKey, box.privateKey),
				"tampered ciphertext must not open",
			);
		},
	},
	{
		name: "open returns null for the wrong recipient",
		run: (backend) => {
			const box = backend.generateBoxKeyPair();
			const stranger = backend.generateBoxKeyPair();
			const sealed = backend.seal(utf8("x"), box.publicKey);
			assertNull(
				backend.open(sealed, stranger.publicKey, stranger.privateKey),
				"wrong recipient must not open",
			);
		},
	},
	{
		name: "sign produces a signature verify accepts",
		run: (backend) => {
			const keys = backend.generateSignKeyPair();
			const message = utf8("sign-me");
			const signature = backend.sign(message, keys.privateKey);
			assertOk(
				backend.verify(message, signature, keys.publicKey),
				"valid signature failed to verify",
			);
		},
	},
	{
		name: "verify rejects a tampered (same-length) signature",
		run: (backend) => {
			const keys = backend.generateSignKeyPair();
			const message = utf8("sign-me");
			const signature = backend.sign(message, keys.privateKey);
			const tampered = signature.slice();
			tampered[0] ^= 0xff;
			assertOk(
				backend.verify(message, tampered, keys.publicKey) === false,
				"tampered signature must verify false",
			);
		},
	},
	{
		name: "verify never accepts a wrong-length signature (fail-closed)",
		run: (backend) => {
			const keys = backend.generateSignKeyPair();
			const message = utf8("sign-me");
			const wrongLength = new Uint8Array([1, 2, 3]);
			let accepted: boolean;
			try {
				accepted = backend.verify(message, wrongLength, keys.publicKey);
			} catch {
				// A binding that throws on a malformed length is fail-closed; the
				// SDK's openAndVerify converts that throw into bad-signature, and
				// RnSodiumBackend.verify catches it so verify stays a total boolean.
				accepted = false;
			}
			assertOk(
				accepted === false,
				"a wrong-length signature must never be accepted",
			);
		},
	},
	{
		name: "hash is deterministic and matches the reference digest",
		run: (backend) => {
			const message = fromHex(V.hash.messageHex);
			const first = backend.hash(message, V.hash.length);
			const second = backend.hash(message, V.hash.length);
			assertEqualBytes(first, second, "hash is not deterministic");
			assertEqual(toHex(first), V.hash.digestHex, "hash digest mismatch");
		},
	},
	{
		name: "hash honors the requested length",
		run: (backend) => {
			assertEqual(backend.hash(utf8("len"), 16).length, 16, "hash length wrong");
		},
	},
	{
		name: "randomBytes returns the requested length and differs across calls",
		run: (backend) => {
			const a = backend.randomBytes(24);
			const b = backend.randomBytes(24);
			assertEqual(a.length, 24, "randomBytes length wrong");
			assertNotEqual(toHex(a), toHex(b), "randomBytes returned identical buffers");
		},
	},
	{
		name: "keypairs are non-empty and sign != box public keys",
		run: (backend) => {
			const sign = backend.generateSignKeyPair();
			const box = backend.generateBoxKeyPair();
			assertOk(sign.publicKey.length > 0, "empty sign public key");
			assertOk(box.publicKey.length > 0, "empty box public key");
			assertNotEqual(
				toHex(sign.publicKey),
				toHex(box.publicKey),
				"sign and box public keys are identical",
			);
		},
	},
	{
		// Forward interop direction (Node-sealed → opened by the backend under
		// test). The reverse direction (RnSodiumBackend-sealed → opened by the
		// Node backend) cannot run inside this single-backend core, so it is
		// covered by the live LAN hello and the captured rn-interop fixture
		// (tests/integration/conformance/rn-interop.test.ts).
		name: "opens a sealed box produced by the reference (Node) backend — Node→RN interop",
		run: (backend) => {
			const opened = backend.open(
				fromHex(V.seal.sealedHex),
				fromHex(V.seal.publicKeyHex),
				fromHex(V.seal.privateKeyHex),
			);
			assertOk(opened !== null, "could not open the reference sealed box");
			assertEqualBytes(
				opened!,
				fromHex(V.seal.plaintextHex),
				"reference sealed box opened to the wrong plaintext",
			);
		},
	},
	{
		name: "reproduces the reference detached signature for fixed keys",
		run: (backend) => {
			const message = fromHex(V.sign.messageHex);
			const signature = backend.sign(message, fromHex(V.sign.privateKeyHex));
			assertEqual(
				toHex(signature),
				V.sign.signatureHex,
				"detached signature mismatch vs reference",
			);
			assertOk(
				backend.verify(
					message,
					fromHex(V.sign.signatureHex),
					fromHex(V.sign.publicKeyHex),
				),
				"reference signature failed to verify",
			);
		},
	},
	{
		name: "reproduces the reference SAS",
		run: (backend) => {
			const sas = computeSAS(
				backend,
				fromHex(V.sas.aSignPubHex),
				fromHex(V.sas.aBoxPubHex),
				fromHex(V.sas.bSignPubHex),
				fromHex(V.sas.bBoxPubHex),
			);
			assertEqual(sas, V.sas.value, "SAS mismatch vs reference");
		},
	},
	{
		name: "envelope seal+sign round-trips and openAndVerify returns ok",
		run: (backend) => {
			const sender = backend.generateSignKeyPair();
			const recipient = backend.generateBoxKeyPair();
			const payload = utf8("envelope");
			const sealed = sealAndSign(
				backend,
				payload,
				sender.privateKey,
				recipient.publicKey,
			);
			const result = openAndVerify(
				backend,
				sealed,
				recipient.publicKey,
				recipient.privateKey,
				sender.publicKey,
			);
			assertOk(result.ok, "openAndVerify did not return ok");
			if (result.ok) {
				assertEqualBytes(result.payloadBytes, payload, "payload mismatch");
			}
		},
	},
	{
		name: "openAndVerify reports decrypt-failed for a tampered envelope",
		run: (backend) => {
			const sender = backend.generateSignKeyPair();
			const recipient = backend.generateBoxKeyPair();
			const sealed = sealAndSign(
				backend,
				utf8("x"),
				sender.privateKey,
				recipient.publicKey,
			);
			sealed[0] ^= 0xff;
			const result = openAndVerify(
				backend,
				sealed,
				recipient.publicKey,
				recipient.privateKey,
				sender.publicKey,
			);
			assertOk(
				!result.ok && result.reason === "decrypt-failed",
				"tampered envelope must be decrypt-failed",
			);
		},
	},
	{
		name: "openAndVerify reports bad-signature for a forged signature",
		run: (backend) => {
			const sender = backend.generateSignKeyPair();
			const wrong = backend.generateSignKeyPair();
			const recipient = backend.generateBoxKeyPair();
			const sealed = sealAndSign(
				backend,
				utf8("x"),
				wrong.privateKey,
				recipient.publicKey,
			);
			const result = openAndVerify(
				backend,
				sealed,
				recipient.publicKey,
				recipient.privateKey,
				sender.publicKey,
			);
			assertOk(
				!result.ok && result.reason === "bad-signature",
				"forged signature must be bad-signature",
			);
		},
	},
];
