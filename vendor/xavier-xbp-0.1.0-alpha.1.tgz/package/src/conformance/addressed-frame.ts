import type { SodiumBackend } from "../crypto/backend.js";
import { openAndVerify, sealAndSign } from "../crypto/envelope.js";
import { fromHex, toHex, utf8 } from "../encoding.js";
import { PROTOCOL_VERSION } from "../protocol/version.js";
import { decodeFrame, encodeFrame } from "../protocol/wire.js";
import { assertEqual, assertOk } from "./assert.js";

export interface AddressedFrameCheck {
	name: string;
	run: (backend: SodiumBackend) => void;
}

// The addressed routing header {to, from, payload} lets a blind relay route by
// NodeId without seeing plaintext; it is advisory and NEVER a trust input. These
// runner-agnostic checks prove the security invariant holds at the addressed-
// frame boundary: the inner seal alone governs access, and tampering with the
// header or redirecting the frame fails closed. Shipped alongside — and separate
// from — backendParityChecks, which stay unchanged.
export const addressedFrameChecks: AddressedFrameCheck[] = [
	{
		name: "addressed frame round-trips to/from/payload",
		run: (backend) => {
			const sender = backend.generateSignKeyPair();
			const recipient = backend.generateBoxKeyPair();
			const sealed = sealAndSign(
				backend,
				utf8("hi"),
				sender.privateKey,
				recipient.publicKey,
			);
			const bytes = encodeFrame({
				t: "addressed",
				v: PROTOCOL_VERSION,
				to: "1111",
				from: "2222",
				payload: toHex(sealed),
			});
			const decoded = decodeFrame(bytes);
			assertOk(decoded?.t === "addressed", "addressed frame did not decode");
			if (decoded?.t !== "addressed") {
				return;
			}
			assertEqual(decoded.to, "1111", "to mismatch");
			assertEqual(decoded.from, "2222", "from mismatch");
			assertEqual(decoded.payload, toHex(sealed), "payload mismatch");
		},
	},
	{
		name: "advisory header: mutating to/from never blocks opening the inner seal",
		run: (backend) => {
			const sender = backend.generateSignKeyPair();
			const recipient = backend.generateBoxKeyPair();
			const sealed = sealAndSign(
				backend,
				utf8("payload"),
				sender.privateKey,
				recipient.publicKey,
			);
			// A relay rewrites the advisory header to garbage; the inner seal is intact.
			const bytes = encodeFrame({
				t: "addressed",
				v: PROTOCOL_VERSION,
				to: "deadbeef",
				from: "deadbeef",
				payload: toHex(sealed),
			});
			const decoded = decodeFrame(bytes);
			assertOk(decoded?.t === "addressed", "addressed frame did not decode");
			if (decoded?.t !== "addressed") {
				return;
			}
			const opened = openAndVerify(
				backend,
				fromHex(decoded.payload),
				recipient.publicKey,
				recipient.privateKey,
				sender.publicKey,
			);
			assertOk(
				opened.ok,
				"the inner seal must open regardless of the advisory header",
			);
		},
	},
	{
		name: "redirect fails closed: a seal addressed to A cannot be opened by B",
		run: (backend) => {
			const sender = backend.generateSignKeyPair();
			const a = backend.generateBoxKeyPair();
			const b = backend.generateBoxKeyPair();
			const sealed = sealAndSign(
				backend,
				utf8("for-A"),
				sender.privateKey,
				a.publicKey,
			);
			// A blind relay redirects `to` toward B; B still cannot open A's seal.
			const opened = openAndVerify(
				backend,
				sealed,
				b.publicKey,
				b.privateKey,
				sender.publicKey,
			);
			assertOk(!opened.ok, "B must not open a seal addressed to A");
		},
	},
	{
		name: "forged from fails closed: a seal signed by an impostor fails verification",
		run: (backend) => {
			const honest = backend.generateSignKeyPair();
			const impostor = backend.generateSignKeyPair();
			const recipient = backend.generateBoxKeyPair();
			// The impostor seals + signs, but the frame claims `from: honest`.
			const sealed = sealAndSign(
				backend,
				utf8("spoof"),
				impostor.privateKey,
				recipient.publicKey,
			);
			const opened = openAndVerify(
				backend,
				sealed,
				recipient.publicKey,
				recipient.privateKey,
				honest.publicKey,
			);
			assertOk(
				!opened.ok && opened.reason === "bad-signature",
				"a forged from must fail closed (bad-signature)",
			);
		},
	},
];
