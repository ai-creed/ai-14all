// A tiny, runner-agnostic assertion surface for the backend-parity core. It
// throws a plain Error so the checks run unchanged under vitest (Node) and on a
// React Native device — no node:assert, no test-runner globals.

export function assertOk(condition: boolean, message: string): void {
	if (!condition) {
		throw new Error(`parity: ${message}`);
	}
}

export function assertEqual<T>(actual: T, expected: T, message: string): void {
	if (actual !== expected) {
		throw new Error(
			`parity: ${message} (expected ${String(expected)}, got ${String(actual)})`,
		);
	}
}

export function assertNotEqual<T>(a: T, b: T, message: string): void {
	if (a === b) {
		throw new Error(`parity: ${message} (both values were ${String(a)})`);
	}
}

export function assertNull(value: unknown, message: string): void {
	if (value !== null) {
		throw new Error(`parity: ${message} (expected null, got ${String(value)})`);
	}
}

export function assertEqualBytes(
	actual: Uint8Array,
	expected: Uint8Array,
	message: string,
): void {
	const equal =
		actual.length === expected.length &&
		actual.every((byte, index) => byte === expected[index]);
	if (!equal) {
		throw new Error(`parity: ${message} (byte arrays differ)`);
	}
}
