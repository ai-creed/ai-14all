import type { SodiumBackend } from "../crypto/backend.js";
import { toHex } from "../encoding.js";

// A NodeId is a stable, transport-independent address: the hex fingerprint of a
// node's Ed25519 sign public key. Pairing already exchanges and SAS-verifies
// that key, so every paired node can address its peers identically on the LAN
// today or through the blind broker later. Routing never depends on IP/host.
export type NodeId = string;

const NODE_ID_BYTES = 16;

export function deriveNodeId(
	backend: SodiumBackend,
	signPublicKey: Uint8Array,
): NodeId {
	return toHex(backend.hash(signPublicKey, NODE_ID_BYTES));
}
