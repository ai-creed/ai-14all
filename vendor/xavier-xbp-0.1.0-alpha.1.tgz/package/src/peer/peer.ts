import type { CapabilityDescriptor } from "@ai-creed/command-contract";
import type { SodiumBackend } from "../crypto/backend.js";
import { openAndVerify, sealAndSign } from "../crypto/envelope.js";
import type { Identity } from "../crypto/identity.js";
import { fromHex, fromUtf8, toHex, utf8 } from "../encoding.js";
import {
	PeerMessage,
	type AckMessage,
	type EventMessage,
	type RequestMessage,
} from "../protocol/peer-messages.js";
import { PROTOCOL_VERSION, isSupportedVersion } from "../protocol/version.js";
import { decodeFrame, encodeFrame } from "../protocol/wire.js";
import { AntiReplay } from "../reference/anti-replay.js";
import type { Transport } from "../transport/transport.js";
import { deriveNodeId, type NodeId } from "./node-id.js";

export interface ReplayGuard {
	check(nonce: string, ts: number): { ok: boolean; reason?: string };
}

// A structural sink so the neutral Peer never imports the concrete file-backed
// AuditLog (which uses node:fs). The reference host passes its AuditLog; the
// phone passes nothing.
export interface AuditSink {
	append(entry: {
		cap: string | null;
		risk: "low" | "medium" | "high" | null;
		outcome: "accepted" | "rejected";
		reason?: string;
	}): void;
}

interface RegisteredPeer {
	signPub: Uint8Array;
	boxPub: Uint8Array;
	permissions: Set<string>;
}

export interface PeerOptions {
	backend: SodiumBackend;
	identity: Identity;
	transport: Transport;
	replayGuard?: ReplayGuard;
	audit?: AuditSink;
	now?: () => number;
	requestTimeoutMs?: number;
}

export class PeerCallError extends Error {
	constructor(
		readonly code: string,
		message: string,
	) {
		super(message);
		this.name = "PeerCallError";
	}
}

type AnyDescriptor = CapabilityDescriptor<unknown, unknown>;
type Handler = (args: unknown) => Promise<unknown> | unknown;

// AckOk's `result` is `z.unknown().refine(v => v !== undefined)`, which zod
// infers as the non-undefined `{} | null` rather than plain `unknown`. A handler
// hands us a plain `unknown`, so we cast at the send site; an undefined result
// is still caught fail-closed by the AckOk schema on the receiving end.
type AckOkResult = Extract<AckMessage, { ok: true }>["result"];

interface Pending {
	resolve: (result: unknown) => void;
	reject: (err: Error) => void;
	timer: ReturnType<typeof setTimeout>;
}

// A symmetric mesh peer. Every node both serves a capability registry and calls
// its peers + receives their events. Pairing + the sealed envelope are reused
// unchanged: a Peer is constructed AFTER pairing and told its peers' keys via
// addPeer(). On the wire it speaks only addressed frames, so it coexists with
// the legacy hello (sealed) path on a single transport.
export class Peer {
	readonly nodeId: NodeId;

	private readonly backend: SodiumBackend;
	private readonly identity: Identity;
	private readonly transport: Transport;
	private readonly replayGuard: ReplayGuard;
	private readonly audit: AuditSink | null;
	private readonly now: () => number;
	private readonly requestTimeoutMs: number;

	private readonly capabilities = new Map<
		string,
		{ descriptor: AnyDescriptor; handler: Handler }
	>();
	private readonly peers = new Map<NodeId, RegisteredPeer>();
	private readonly pending = new Map<string, Pending>();
	private readonly eventHandlers = new Set<
		(from: NodeId, topic: string, payload: unknown) => void
	>();
	private off: (() => void) | null = null;

	constructor(options: PeerOptions) {
		this.backend = options.backend;
		this.identity = options.identity;
		this.transport = options.transport;
		this.replayGuard = options.replayGuard ?? new AntiReplay();
		this.audit = options.audit ?? null;
		this.now = options.now ?? (() => Date.now());
		this.requestTimeoutMs = options.requestTimeoutMs ?? 4000;
		this.nodeId = deriveNodeId(this.backend, this.identity.sign.publicKey);
	}

	start(): void {
		if (this.off) {
			return;
		}
		this.off = this.transport.onFrame((frame) => this.onFrame(frame));
	}

	stop(): void {
		this.off?.();
		this.off = null;
		for (const pending of this.pending.values()) {
			clearTimeout(pending.timer);
			pending.reject(new PeerCallError("stopped", "peer stopped"));
		}
		this.pending.clear();
	}

	// Register a SAS-verified peer's keys. Returns the peer's NodeId so callers
	// can address it. permissions are the capability permissions this node grants
	// that peer (e.g. ["control:read"]).
	addPeer(
		signPub: Uint8Array,
		boxPub: Uint8Array,
		permissions: string[],
	): NodeId {
		const nodeId = deriveNodeId(this.backend, signPub);
		this.peers.set(nodeId, { signPub, boxPub, permissions: new Set(permissions) });
		return nodeId;
	}

	expose<A, R>(
		cap: CapabilityDescriptor<A, R>,
		handler: (args: A) => Promise<R> | R,
	): void {
		this.capabilities.set(cap.id, {
			descriptor: cap as AnyDescriptor,
			handler: handler as Handler,
		});
	}

	onEvent(
		handler: (from: NodeId, topic: string, payload: unknown) => void,
	): () => void {
		this.eventHandlers.add(handler);
		return () => this.eventHandlers.delete(handler);
	}

	async call<A, R>(
		to: NodeId,
		cap: CapabilityDescriptor<A, R>,
		args: A,
	): Promise<R> {
		const peer = this.peers.get(to);
		if (!peer) {
			throw new PeerCallError("unknown-peer", `no paired peer ${to}`);
		}
		const parsedArgs = cap.args.safeParse(args);
		if (!parsedArgs.success) {
			throw new PeerCallError("schema-invalid", "args failed local validation");
		}
		const requestId = toHex(this.backend.randomBytes(16));
		const message: RequestMessage = {
			v: PROTOCOL_VERSION,
			kind: "request",
			requestId,
			capabilityId: cap.id,
			args: parsedArgs.data,
			nonce: toHex(this.backend.randomBytes(16)),
			ts: this.now(),
		};
		const frame = this.sealFor(peer, to, message);
		const result = await new Promise<unknown>((resolve, reject) => {
			const timer = setTimeout(() => {
				this.pending.delete(requestId);
				reject(new PeerCallError("timeout", "peer call timed out"));
			}, this.requestTimeoutMs);
			(timer as { unref?: () => void }).unref?.();
			this.pending.set(requestId, { resolve, reject, timer });
			this.transport.send(frame).catch((err: unknown) => {
				this.pending.delete(requestId);
				clearTimeout(timer);
				reject(err instanceof Error ? err : new Error(String(err)));
			});
		});
		const parsedResult = cap.result.safeParse(result);
		if (!parsedResult.success) {
			throw new PeerCallError("bad-result", "result failed schema validation");
		}
		return parsedResult.data;
	}

	emit(to: NodeId, topic: string, payload: unknown): void {
		const peer = this.peers.get(to);
		if (!peer) {
			throw new PeerCallError("unknown-peer", `no paired peer ${to}`);
		}
		const message: EventMessage = {
			v: PROTOCOL_VERSION,
			kind: "event",
			topic,
			payload,
			nonce: toHex(this.backend.randomBytes(16)),
			ts: this.now(),
		};
		void this.transport.send(this.sealFor(peer, to, message));
	}

	private sealFor(
		peer: RegisteredPeer,
		to: NodeId,
		message: RequestMessage | AckMessage | EventMessage,
	): Uint8Array {
		const sealed = sealAndSign(
			this.backend,
			utf8(JSON.stringify(message)),
			this.identity.sign.privateKey,
			peer.boxPub,
		);
		return encodeFrame({
			t: "addressed",
			v: PROTOCOL_VERSION,
			to,
			from: this.nodeId,
			payload: toHex(sealed),
		});
	}

	private onFrame(frameBytes: Uint8Array): void {
		const frame = decodeFrame(frameBytes);
		if (!frame || frame.t !== "addressed") {
			return; // not Peer traffic; the legacy host owns sealed/pair frames
		}
		const sender = this.peers.get(frame.from);
		if (!sender) {
			this.rejectAudit(null, "unknown-peer");
			return;
		}
		const opened = openAndVerify(
			this.backend,
			fromHex(frame.payload),
			this.identity.box.publicKey,
			this.identity.box.privateKey,
			sender.signPub,
		);
		if (!opened.ok) {
			this.rejectAudit(null, opened.reason);
			return;
		}
		let message: PeerMessage;
		try {
			const parsed = PeerMessage.safeParse(
				JSON.parse(fromUtf8(opened.payloadBytes)),
			);
			if (!parsed.success) {
				this.rejectAudit(null, "malformed-payload");
				return;
			}
			message = parsed.data;
		} catch {
			this.rejectAudit(null, "malformed-payload");
			return;
		}
		if (!isSupportedVersion(message.v)) {
			this.rejectAudit(null, "unsupported-version");
			return;
		}
		const replay = this.replayGuard.check(message.nonce, message.ts);
		if (!replay.ok) {
			this.rejectAudit(null, replay.reason ?? "replay");
			return;
		}
		if (message.kind === "ack") {
			this.resolveAck(message);
		} else if (message.kind === "event") {
			for (const handler of this.eventHandlers) {
				handler(frame.from, message.topic, message.payload);
			}
		} else {
			void this.dispatchRequest(frame.from, sender, message);
		}
	}

	private async dispatchRequest(
		from: NodeId,
		sender: RegisteredPeer,
		message: RequestMessage,
	): Promise<void> {
		const entry = this.capabilities.get(message.capabilityId);
		if (!entry) {
			this.sendAckError(sender, from, message.requestId, "unknown-capability");
			this.rejectAudit(message.capabilityId, "unknown-capability");
			return;
		}
		const parsed = entry.descriptor.args.safeParse(message.args);
		if (!parsed.success) {
			this.sendAckError(sender, from, message.requestId, "schema-invalid");
			this.rejectAudit(message.capabilityId, "schema-invalid", entry.descriptor.risk);
			return;
		}
		if (!sender.permissions.has(entry.descriptor.permission)) {
			this.sendAckError(sender, from, message.requestId, "permission-denied");
			this.rejectAudit(message.capabilityId, "permission-denied", entry.descriptor.risk);
			return;
		}
		let result: unknown;
		try {
			result = await entry.handler(parsed.data);
		} catch {
			this.sendAckError(sender, from, message.requestId, "handler-error");
			this.rejectAudit(message.capabilityId, "handler-error", entry.descriptor.risk);
			return;
		}
		this.audit?.append({
			cap: message.capabilityId,
			risk: entry.descriptor.risk,
			outcome: "accepted",
		});
		this.sendAckOk(sender, from, message.requestId, result);
	}

	private resolveAck(message: AckMessage): void {
		const pending = this.pending.get(message.requestId);
		if (!pending) {
			return;
		}
		this.pending.delete(message.requestId);
		clearTimeout(pending.timer);
		if (message.ok) {
			// Narrowed to the ok branch (AckOk): result is present.
			pending.resolve(message.result);
		} else {
			// Narrowed to the error branch (AckError): error is present.
			pending.reject(new PeerCallError(message.error.code, message.error.message));
		}
	}

	private sendAckOk(
		peer: RegisteredPeer,
		to: NodeId,
		requestId: string,
		result: unknown,
	): void {
		const ack: AckMessage = {
			v: PROTOCOL_VERSION,
			kind: "ack",
			requestId,
			ok: true,
			result: result as AckOkResult,
			nonce: toHex(this.backend.randomBytes(16)),
			ts: this.now(),
		};
		void this.transport.send(this.sealFor(peer, to, ack));
	}

	private sendAckError(
		peer: RegisteredPeer,
		to: NodeId,
		requestId: string,
		code: string,
	): void {
		const ack: AckMessage = {
			v: PROTOCOL_VERSION,
			kind: "ack",
			requestId,
			ok: false,
			error: { code, message: code },
			nonce: toHex(this.backend.randomBytes(16)),
			ts: this.now(),
		};
		void this.transport.send(this.sealFor(peer, to, ack));
	}

	private rejectAudit(
		cap: string | null,
		reason: string,
		risk: "low" | "medium" | "high" | null = null,
	): void {
		this.audit?.append({ cap, risk, outcome: "rejected", reason });
	}
}
