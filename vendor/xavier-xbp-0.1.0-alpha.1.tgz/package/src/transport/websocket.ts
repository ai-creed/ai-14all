import { WebSocket, WebSocketServer } from "ws";
import type { Transport } from "./transport.js";

function toUint8Array(data: unknown): Uint8Array {
	if (data instanceof ArrayBuffer) {
		return new Uint8Array(data);
	}
	if (Array.isArray(data)) {
		return new Uint8Array(Buffer.concat(data as Buffer[]));
	}
	return new Uint8Array(data as Buffer);
}

function wrapSocket(socket: WebSocket): Transport {
	const handlers = new Set<(frame: Uint8Array) => void>();
	// Frames can arrive in the SAME read as the WebSocket handshake response
	// (the relay forwards the peer's first sealed frame the instant it splices,
	// which the OS may coalesce with the 101). ws emits those "message" events
	// synchronously right after "open", before a caller wired via
	// connectWebSocketClient has had a microtask to register onFrame. Buffer
	// everything that lands before the first handler so nothing is lost, then
	// flush it in arrival order the moment onFrame is first called.
	let everHadHandler = false;
	const backlog: Uint8Array[] = [];
	socket.on("message", (data) => {
		const frame = toUint8Array(data);
		if (!everHadHandler) {
			backlog.push(frame);
			return;
		}
		for (const handler of handlers) {
			handler(frame);
		}
	});

	return {
		async send(frame: Uint8Array): Promise<void> {
			await new Promise<void>((resolve, reject) => {
				socket.send(frame, (err) => (err ? reject(err) : resolve()));
			});
		},
		onFrame(handler) {
			handlers.add(handler);
			if (!everHadHandler) {
				everHadHandler = true;
				const queued = backlog.splice(0);
				for (const frame of queued) {
					for (const registered of handlers) {
						registered(frame);
					}
				}
			}
			return () => handlers.delete(handler);
		},
		async close(): Promise<void> {
			handlers.clear();
			socket.close();
		},
	};
}

export interface WebSocketHost {
	port: number;
	nextConnection(): Promise<Transport>;
	close(): Promise<void>;
}

export async function startWebSocketHost(
	port = 0,
	host = "127.0.0.1",
): Promise<WebSocketHost> {
	const server = new WebSocketServer({ port, host });
	await new Promise<void>((resolve) =>
		server.once("listening", () => resolve()),
	);
	const address = server.address();
	const boundPort =
		typeof address === "object" && address ? address.port : port;

	const pending: WebSocket[] = [];
	const waiters: Array<(socket: WebSocket) => void> = [];
	server.on("connection", (socket) => {
		const waiter = waiters.shift();
		if (waiter) {
			waiter(socket);
		} else {
			pending.push(socket);
		}
	});

	return {
		port: boundPort,
		async nextConnection(): Promise<Transport> {
			const ready = pending.shift();
			if (ready) {
				return wrapSocket(ready);
			}
			const socket = await new Promise<WebSocket>((resolve) =>
				waiters.push(resolve),
			);
			return wrapSocket(socket);
		},
		async close(): Promise<void> {
			await new Promise<void>((resolve) => server.close(() => resolve()));
		},
	};
}

export async function connectWebSocketClient(url: string): Promise<Transport> {
	const socket = new WebSocket(url);
	// Wrap BEFORE awaiting "open" so the message listener is attached
	// synchronously at socket creation. A frame coalesced with the handshake
	// then lands in wrapSocket's backlog (flushed on the first onFrame) instead
	// of firing before any listener exists and being dropped.
	const transport = wrapSocket(socket);
	await new Promise<void>((resolve, reject) => {
		socket.once("open", () => resolve());
		socket.once("error", reject);
	});
	return transport;
}
