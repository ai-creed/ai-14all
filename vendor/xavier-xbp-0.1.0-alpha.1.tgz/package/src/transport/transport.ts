export interface Transport {
	send(frame: Uint8Array): Promise<void>;
	onFrame(handler: (frame: Uint8Array) => void): () => void;
	// The link died on us. Without this, a dead link is indistinguishable from a
	// slow one — calls just time out and every layer above keeps believing the
	// session is alive, which leaves a peer unable to notice it should reconnect.
	//
	// It is NEVER fired by our own close(): a deliberate hang-up is not a loss.
	// The phone drops its session and reconnects on this signal, so a self-fired
	// close would resurrect the session the user just disconnected.
	//
	// Optional so implementors that cannot observe closure keep compiling. A
	// caller must treat its absence as "closure is unobservable here", not as
	// "the link is healthy".
	onClose?(handler: () => void): () => void;
	close(): Promise<void>;
}
