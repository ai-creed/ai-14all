import type { Transport } from "./transport.js";

class InMemoryEndpoint implements Transport {
	private readonly handlers = new Set<(frame: Uint8Array) => void>();
	private readonly closeHandlers = new Set<() => void>();
	private peer: InMemoryEndpoint | null = null;
	private closed = false;

	link(peer: InMemoryEndpoint): void {
		this.peer = peer;
	}

	async send(frame: Uint8Array): Promise<void> {
		const peer = this.peer;
		if (!peer || this.closed) {
			return;
		}
		await Promise.resolve();
		if (peer.closed) {
			return;
		}
		for (const handler of peer.handlers) {
			handler(frame);
		}
	}

	onFrame(handler: (frame: Uint8Array) => void): () => void {
		this.handlers.add(handler);
		return () => this.handlers.delete(handler);
	}

	onClose(handler: () => void): () => void {
		this.closeHandlers.add(handler);
		return () => this.closeHandlers.delete(handler);
	}

	// Our peer hung up, so OUR link is gone. Draining the set before dispatch
	// makes this fire at most once, even if a handler closes us re-entrantly.
	private linkLost(): void {
		if (this.closed) {
			return;
		}
		const handlers = [...this.closeHandlers];
		this.closeHandlers.clear();
		for (const handler of handlers) {
			handler();
		}
	}

	async close(): Promise<void> {
		if (this.closed) {
			return;
		}
		this.closed = true;
		this.handlers.clear();
		// We hung up: drop our own close subscribers BEFORE telling the peer, so
		// nothing can route our deliberate close back to us as a link loss.
		this.closeHandlers.clear();
		this.peer?.linkLost();
	}
}

export function createInMemoryPair(): [Transport, Transport] {
	const a = new InMemoryEndpoint();
	const b = new InMemoryEndpoint();
	a.link(b);
	b.link(a);
	return [a, b];
}
