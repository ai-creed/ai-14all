export function toHex(bytes: Uint8Array): string {
	let out = "";
	for (const byte of bytes) {
		out += byte.toString(16).padStart(2, "0");
	}
	return out;
}

export function fromHex(hex: string): Uint8Array {
	const matches = hex.match(/.{1,2}/g) ?? [];
	return Uint8Array.from(matches.map((pair) => parseInt(pair, 16)));
}

const encoder = new TextEncoder();
const decoder = new TextDecoder();

export function utf8(text: string): Uint8Array {
	return encoder.encode(text);
}

export function fromUtf8(bytes: Uint8Array): string {
	return decoder.decode(bytes);
}

export function concatBytes(...arrays: Uint8Array[]): Uint8Array {
	const total = arrays.reduce((sum, arr) => sum + arr.length, 0);
	const out = new Uint8Array(total);
	let offset = 0;
	for (const arr of arrays) {
		out.set(arr, offset);
		offset += arr.length;
	}
	return out;
}

export function compareBytes(a: Uint8Array, b: Uint8Array): number {
	const len = Math.min(a.length, b.length);
	for (let i = 0; i < len; i++) {
		if (a[i] !== b[i]) {
			return a[i] - b[i];
		}
	}
	return a.length - b.length;
}
