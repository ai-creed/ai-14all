import { fromHex, toHex } from "../encoding.js";
import type { KeyPair, SodiumBackend } from "./backend.js";

export interface Identity {
	sign: KeyPair;
	box: KeyPair;
}

export interface IdentityFile {
	signPublicKeyHex: string;
	signPrivateKeyHex: string;
	boxPublicKeyHex: string;
	boxPrivateKeyHex: string;
}

export function generateIdentity(backend: SodiumBackend): Identity {
	return {
		sign: backend.generateSignKeyPair(),
		box: backend.generateBoxKeyPair(),
	};
}

export function serializeIdentity(identity: Identity): IdentityFile {
	return {
		signPublicKeyHex: toHex(identity.sign.publicKey),
		signPrivateKeyHex: toHex(identity.sign.privateKey),
		boxPublicKeyHex: toHex(identity.box.publicKey),
		boxPrivateKeyHex: toHex(identity.box.privateKey),
	};
}

export function deserializeIdentity(file: IdentityFile): Identity {
	return {
		sign: {
			publicKey: fromHex(file.signPublicKeyHex),
			privateKey: fromHex(file.signPrivateKeyHex),
		},
		box: {
			publicKey: fromHex(file.boxPublicKeyHex),
			privateKey: fromHex(file.boxPrivateKeyHex),
		},
	};
}
