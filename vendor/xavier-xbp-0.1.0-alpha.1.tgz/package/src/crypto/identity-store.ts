import { readFileSync, writeFileSync } from "node:fs";
import {
	deserializeIdentity,
	serializeIdentity,
	type Identity,
	type IdentityFile,
} from "./identity.js";

export function saveIdentity(path: string, identity: Identity): void {
	writeFileSync(path, JSON.stringify(serializeIdentity(identity), null, 2));
}

export function loadIdentity(path: string): Identity {
	const file = JSON.parse(readFileSync(path, "utf8")) as IdentityFile;
	return deserializeIdentity(file);
}
