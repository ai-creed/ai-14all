import { fromHex, fromUtf8, toHex, utf8 } from "../encoding.js";
import type { SodiumBackend } from "./backend.js";

interface InnerEnvelope {
	p: string;
	s: string;
}

export function sealAndSign(
	backend: SodiumBackend,
	payloadBytes: Uint8Array,
	senderSignPrivateKey: Uint8Array,
	recipientBoxPublicKey: Uint8Array,
): Uint8Array {
	const signature = backend.sign(payloadBytes, senderSignPrivateKey);
	const inner: InnerEnvelope = { p: toHex(payloadBytes), s: toHex(signature) };
	return backend.seal(utf8(JSON.stringify(inner)), recipientBoxPublicKey);
}

export type OpenResult =
	| { ok: true; payloadBytes: Uint8Array }
	| { ok: false; reason: "decrypt-failed" | "bad-signature" | "malformed" };

export function openAndVerify(
	backend: SodiumBackend,
	ciphertext: Uint8Array,
	recipientBoxPublicKey: Uint8Array,
	recipientBoxPrivateKey: Uint8Array,
	senderSignPublicKey: Uint8Array,
): OpenResult {
	const opened = backend.open(
		ciphertext,
		recipientBoxPublicKey,
		recipientBoxPrivateKey,
	);
	if (!opened) {
		return { ok: false, reason: "decrypt-failed" };
	}

	let inner: InnerEnvelope;
	try {
		inner = JSON.parse(fromUtf8(opened)) as InnerEnvelope;
	} catch {
		return { ok: false, reason: "malformed" };
	}
	if (typeof inner?.p !== "string" || typeof inner?.s !== "string") {
		return { ok: false, reason: "malformed" };
	}

	const payloadBytes = fromHex(inner.p);
	const signature = fromHex(inner.s);
	try {
		if (!backend.verify(payloadBytes, signature, senderSignPublicKey)) {
			return { ok: false, reason: "bad-signature" };
		}
	} catch {
		return { ok: false, reason: "bad-signature" };
	}

	return { ok: true, payloadBytes };
}
