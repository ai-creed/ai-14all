import { createRequire } from "node:module";
import type { KeyPair, SodiumBackend } from "./backend.js";

interface LibsodiumLike {
	ready: Promise<void>;
	crypto_sign_keypair(): { publicKey: Uint8Array; privateKey: Uint8Array };
	crypto_box_keypair(): { publicKey: Uint8Array; privateKey: Uint8Array };
	crypto_sign_detached(message: Uint8Array, privateKey: Uint8Array): Uint8Array;
	crypto_sign_verify_detached(
		signature: Uint8Array,
		message: Uint8Array,
		publicKey: Uint8Array,
	): boolean;
	crypto_box_seal(message: Uint8Array, publicKey: Uint8Array): Uint8Array;
	crypto_box_seal_open(
		ciphertext: Uint8Array,
		publicKey: Uint8Array,
		privateKey: Uint8Array,
	): Uint8Array;
	crypto_generichash(hashLength: number, message: Uint8Array): Uint8Array;
	randombytes_buf(length: number): Uint8Array;
}

export async function createNodeSodiumBackend(): Promise<SodiumBackend> {
	const require = createRequire(import.meta.url);
	const sodium = require("libsodium-wrappers") as LibsodiumLike;
	await sodium.ready;

	return {
		generateSignKeyPair(): KeyPair {
			const pair = sodium.crypto_sign_keypair();
			return { publicKey: pair.publicKey, privateKey: pair.privateKey };
		},
		generateBoxKeyPair(): KeyPair {
			const pair = sodium.crypto_box_keypair();
			return { publicKey: pair.publicKey, privateKey: pair.privateKey };
		},
		sign(message, signPrivateKey) {
			return sodium.crypto_sign_detached(message, signPrivateKey);
		},
		verify(message, signature, signPublicKey) {
			return sodium.crypto_sign_verify_detached(
				signature,
				message,
				signPublicKey,
			);
		},
		seal(message, recipientBoxPublicKey) {
			return sodium.crypto_box_seal(message, recipientBoxPublicKey);
		},
		open(ciphertext, recipientBoxPublicKey, recipientBoxPrivateKey) {
			try {
				return sodium.crypto_box_seal_open(
					ciphertext,
					recipientBoxPublicKey,
					recipientBoxPrivateKey,
				);
			} catch {
				return null;
			}
		},
		hash(message, length) {
			return sodium.crypto_generichash(length, message);
		},
		randomBytes(length) {
			return sodium.randombytes_buf(length);
		},
	};
}
