import { compareBytes, concatBytes } from "../encoding.js";
import type { SodiumBackend } from "./backend.js";

export function computeSAS(
	backend: SodiumBackend,
	aSignPub: Uint8Array,
	aBoxPub: Uint8Array,
	bSignPub: Uint8Array,
	bBoxPub: Uint8Array,
): string {
	const partyA = concatBytes(aSignPub, aBoxPub);
	const partyB = concatBytes(bSignPub, bBoxPub);
	const [first, second] =
		compareBytes(partyA, partyB) <= 0 ? [partyA, partyB] : [partyB, partyA];
	const digest = backend.hash(concatBytes(first, second), 32);
	const value =
		((digest[0] << 24) | (digest[1] << 16) | (digest[2] << 8) | digest[3]) >>>
		0;
	return String(value % 1_000_000).padStart(6, "0");
}
