export interface KeyPair {
	publicKey: Uint8Array;
	privateKey: Uint8Array;
}

export interface SodiumBackend {
	generateSignKeyPair(): KeyPair;
	generateBoxKeyPair(): KeyPair;
	sign(message: Uint8Array, signPrivateKey: Uint8Array): Uint8Array;
	verify(
		message: Uint8Array,
		signature: Uint8Array,
		signPublicKey: Uint8Array,
	): boolean;
	seal(message: Uint8Array, recipientBoxPublicKey: Uint8Array): Uint8Array;
	open(
		ciphertext: Uint8Array,
		recipientBoxPublicKey: Uint8Array,
		recipientBoxPrivateKey: Uint8Array,
	): Uint8Array | null;
	hash(message: Uint8Array, length: number): Uint8Array;
	randomBytes(length: number): Uint8Array;
}
