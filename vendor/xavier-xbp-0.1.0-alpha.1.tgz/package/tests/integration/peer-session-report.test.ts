import { describe, expect, it } from "vitest";
import {
	SESSION_CHANGED_TOPIC,
	SessionReportResult,
	sessionReportCapability,
} from "@ai-creed/command-contract";
import {
	createInMemoryPair,
	createNodeSodiumBackend,
	emitSampleSessionChanged,
	exposeSessionReport,
	generateIdentity,
	Peer,
	SESSION_REPORT_STUB,
	type Transport,
} from "../../src/index.node.js";

describe("reference Peer host exposes session-report", () => {
	it("returns the structured stub and emits a sample event", async () => {
		const backend = await createNodeSodiumBackend();
		const hostId = generateIdentity(backend);
		const phoneId = generateIdentity(backend);
		const [hostT, phoneT]: [Transport, Transport] = createInMemoryPair();

		const host = new Peer({ backend, identity: hostId, transport: hostT });
		const phone = new Peer({
			backend,
			identity: phoneId,
			transport: phoneT,
			requestTimeoutMs: 500,
		});
		const phoneNode = host.addPeer(
			phoneId.sign.publicKey,
			phoneId.box.publicKey,
			[sessionReportCapability.permission],
		);
		const hostNode = phone.addPeer(
			hostId.sign.publicKey,
			hostId.box.publicKey,
			[],
		);
		exposeSessionReport(host);
		host.start();
		phone.start();

		const events: string[] = [];
		phone.onEvent((_from, topic) => events.push(topic));

		const result = await phone.call(hostNode, sessionReportCapability, {});
		expect(SessionReportResult.safeParse(result).success).toBe(true);
		expect(result).toEqual(SESSION_REPORT_STUB);

		emitSampleSessionChanged(host, phoneNode);
		await new Promise((r) => setTimeout(r, 20));
		expect(events).toContain(SESSION_CHANGED_TOPIC);
	});
});
