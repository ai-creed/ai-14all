import { describe, expect, it } from "vitest";
import { z } from "zod";
import {
	type CapabilityDescriptor,
	ptyInputCapability,
} from "@ai-creed/command-contract";
import {
	createInMemoryPair,
	createNodeSodiumBackend,
	generateIdentity,
	Peer,
	type AuditSink,
	type Transport,
} from "../../src/index.node.js";

const cc = (n: number) => String.fromCharCode(n); // never a literal control byte in source
const VALID = {
	worktreeId: "wt1",
	agentId: "a1",
	chunks: [{ text: "hi" }, { key: "enter" as const }],
};

type Entry = {
	cap: string | null;
	risk: "low" | "medium" | "high" | null;
	outcome: "accepted" | "rejected";
	reason?: string;
};

async function makePair(opts: {
	grant: boolean;
	handler: (args: unknown) => unknown;
}) {
	const backend = await createNodeSodiumBackend();
	const hostId = generateIdentity(backend);
	const phoneId = generateIdentity(backend);
	const [hostT, phoneT]: [Transport, Transport] = createInMemoryPair();
	const entries: Entry[] = [];
	const audit: AuditSink = { append: (e) => entries.push(e as Entry) };
	const host = new Peer({ backend, identity: hostId, transport: hostT, audit });
	const phone = new Peer({
		backend,
		identity: phoneId,
		transport: phoneT,
		requestTimeoutMs: 500,
	});
	const hostNode = phone.addPeer(
		hostId.sign.publicKey,
		hostId.box.publicKey,
		[],
	);
	host.addPeer(
		phoneId.sign.publicKey,
		phoneId.box.publicKey,
		opts.grant ? [ptyInputCapability.permission] : [],
	);
	host.expose(ptyInputCapability, opts.handler as (a: unknown) => unknown);
	host.start();
	phone.start();
	return { phone, hostNode, entries };
}

describe("pty-input Peer conformance", () => {
	it("rejects a caller lacking control:pty-write (permission-denied, high-risk audit)", async () => {
		const { phone, hostNode, entries } = await makePair({
			grant: false,
			handler: () => ({ ok: true, appliedAt: 1 }),
		});
		await expect(
			phone.call(hostNode, ptyInputCapability, VALID),
		).rejects.toMatchObject({ code: "permission-denied" });
		const rej = entries.find((e) => e.outcome === "rejected");
		expect(rej?.reason).toBe("permission-denied");
		expect(rej?.cap).toBe(ptyInputCapability.id);
		expect(rej?.risk).toBe("high");
	});

	it("rejects every malformed caller argument client-side before sending (never reaches the host)", async () => {
		let handlerCalls = 0;
		const { phone, hostNode, entries } = await makePair({
			grant: true,
			handler: () => {
				handlerCalls++;
				return { ok: true, appliedAt: 1 };
			},
		});
		// Peer.call validates args against the real strict schema BEFORE sending
		// (peer.ts cap.args.safeParse → PeerCallError), so each malformed shape
		// rejects at the CALLER and no frame ever reaches the host.
		const rejectCaller = (chunks: unknown) =>
			expect(
				phone.call(hostNode, ptyInputCapability, {
					worktreeId: "w",
					agentId: "a",
					chunks,
				}),
			).rejects.toMatchObject({ code: "schema-invalid" });
		await rejectCaller([]); // empty chunk list
		await rejectCaller([{ text: "hi", key: "enter" }]); // both text + key
		await rejectCaller([{}]); // neither text nor key
		await rejectCaller([{ text: "x" + cc(3) }]); // control byte (ETX) in text
		// PROVES the CLIENT layer, not the server: nothing reached dispatchRequest.
		// `schema-invalid` alone is insufficient — the server produces the same code
		// (peer.ts:306-310). A regression removing Peer.call's local safeParse
		// (peer.ts:169-172) would let these frames land server-side (still
		// schema-invalid) and each would append a rejected audit entry + could reach
		// the handler — so these two assertions would then fail.
		expect(entries).toHaveLength(0);
		expect(handlerCalls).toBe(0);
		// Positive control: a VALID call DOES reach the host (handler runs, audit
		// records an accepted entry), proving the pair transports — so the empty
		// audit above is a real client-side stop, not a dead link.
		await expect(
			phone.call(hostNode, ptyInputCapability, VALID),
		).resolves.toEqual({ ok: true, appliedAt: 1 });
		expect(handlerCalls).toBe(1);
		expect(entries.some((e) => e.outcome === "accepted")).toBe(true);
	});

	it("rejects a control byte in { text } server-side even when the client skips validation", async () => {
		const { phone, hostNode, entries } = await makePair({
			grant: true,
			handler: () => ({ ok: true, appliedAt: 1 }),
		});
		// A downlevel/malicious client that loosens its own arg schema (z.any) still
		// hits the host's strict schema at dispatch → schema-invalid.
		const loose = {
			...ptyInputCapability,
			args: z.any(),
			result: z.any(),
		} as unknown as CapabilityDescriptor<unknown, unknown>;
		const smuggled = {
			worktreeId: "w",
			agentId: "a",
			chunks: [{ text: "x" + cc(3) }],
		}; // embedded ETX
		await expect(phone.call(hostNode, loose, smuggled)).rejects.toMatchObject({
			code: "schema-invalid",
		});
		expect(
			entries.some(
				(e) => e.outcome === "rejected" && e.reason === "schema-invalid",
			),
		).toBe(true);
	});

	it("records risk: high on an accepted request", async () => {
		const { phone, hostNode, entries } = await makePair({
			grant: true,
			handler: () => ({ ok: true, appliedAt: 7 }),
		});
		const res = await phone.call(hostNode, ptyInputCapability, VALID);
		expect(res).toEqual({ ok: true, appliedAt: 7 });
		const acc = entries.find((e) => e.outcome === "accepted");
		expect(acc?.cap).toBe(ptyInputCapability.id);
		expect(acc?.risk).toBe("high");
	});

	it("rejects a malformed handler result at the caller (bad-result); a well-formed refusal resolves", async () => {
		const bad = await makePair({ grant: true, handler: () => ({ ok: true }) }); // missing appliedAt
		await expect(
			bad.phone.call(bad.hostNode, ptyInputCapability, VALID),
		).rejects.toMatchObject({ code: "bad-result" });

		const refusal = await makePair({
			grant: true,
			handler: () => ({ ok: false, code: "no-live-agent" }),
		});
		const res = await refusal.phone.call(
			refusal.hostNode,
			ptyInputCapability,
			VALID,
		);
		expect(res).toEqual({ ok: false, code: "no-live-agent" });
	});
});
