// Captured on-device during the 0b.1b acceptance run (Task 10): a sealed box
// produced by RnSodiumBackend for the reference recipient (PARITY_VECTORS.seal).
// The phone's parity screen prints the hex; paste it into sealedHex. The Node
// test below then proves the Node backend opens it (RN → Node interoperability).
export const RN_INTEROP_VECTOR = {
	plaintext: "xbp-rn-to-node-interop",
	sealedHex:
		"e869cf37e7ea0ad16ffad85a282c403fab694268bbd4b7b70551683b26c6887582f915c182539d98d814b7edf751f2ec903bf276d03d76b776ead05300a9ce8b8b2cec6cba4f",
};
