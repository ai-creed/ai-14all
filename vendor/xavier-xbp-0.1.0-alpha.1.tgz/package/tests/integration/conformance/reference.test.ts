import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { createReferenceHarness } from "./reference-harness.js";
import { runConformanceSuite } from "./suite.js";
// NEW: import the suite from the published subpath, not the test-tree file.
import { conformanceChecks as publishedChecks } from "@xavier/xbp/conformance";

describe("@xavier/xbp/conformance subpath", () => {
	it("exposes the host conformance checks as a public surface", () => {
		expect(Array.isArray(publishedChecks)).toBe(true);
		expect(publishedChecks.length).toBeGreaterThan(0);
		expect(publishedChecks.every((c) => typeof c.run === "function")).toBe(true);
	});
});

describe("XBP conformance — reference implementation", () => {
	let dir: string;

	beforeAll(() => {
		dir = mkdtempSync(join(tmpdir(), "xbp-conf-"));
	});

	afterAll(() => {
		rmSync(dir, { recursive: true, force: true });
	});

	runConformanceSuite((opts) => createReferenceHarness(dir, opts));
});
