import { mkdtempSync } from "node:fs";
import { join } from "node:path";
import {
	AntiReplay,
	AuditLog,
	CapabilityRegistry,
	createNodeSodiumBackend,
	decodeFrame,
	generateIdentity,
	helloCapability,
	PairAccept,
	ReferenceClient,
	ReferenceHost,
	toHex,
} from "../../../src/index.node.js";
import type { ConformanceHarness } from "./suite.js";

export async function createReferenceHarness(
	dir: string,
	opts: { grantedPermissions?: string[]; alwaysConfirmPairing?: boolean } = {},
): Promise<ConformanceHarness> {
	const backend = await createNodeSodiumBackend();
	const registry = new CapabilityRegistry();
	registry.register(helloCapability);
	const audit = new AuditLog(join(mkdtempSync(join(dir, "h-")), "audit.jsonl"));
	const host = new ReferenceHost({
		backend,
		identity: generateIdentity(backend),
		registry,
		antiReplay: new AntiReplay(),
		audit,
		handlers: {
			hello: (params) => ({
				youSaid: (params as { greeting: string }).greeting,
			}),
		},
		grantedPermissions: opts.grantedPermissions,
	});
	const client = new ReferenceClient({
		backend,
		identity: generateIdentity(backend),
	});

	const finishPairing = (clientSas: string) => {
		const hostSas = host.lastSas as string;
		// alwaysConfirmPairing forces a "true" confirmation regardless of the SAS —
		// this is the non-conforming behavior the teeth test exercises.
		const confirmed = opts.alwaysConfirmPairing ? true : hostSas === clientSas;
		host.confirmPairing(confirmed);
		client.confirmPairing(confirmed);
		return { hostSas, clientSas, paired: host.isPaired };
	};

	return {
		backend,
		pair() {
			const offer = host.createPairingOffer();
			const accept = PairAccept.parse(
				decodeFrame(host.handle(client.buildPairRequest(offer.token))!),
			);
			return finishPairing(client.acceptPairResponse(accept, offer));
		},
		pairWithSubstitutedKey() {
			const offer = host.createPairingOffer();
			const accept = PairAccept.parse(
				decodeFrame(host.handle(client.buildPairRequest(offer.token))!),
			);
			const attacker = backend.generateBoxKeyPair();
			return finishPairing(
				client.acceptPairResponse(accept, {
					...offer,
					boxPubHex: toHex(attacker.publicKey),
				}),
			);
		},
		send(cap, params, sendOpts) {
			const before = audit.entries().length;
			const ackBytes = host.handle(client.buildRequest(cap, params, sendOpts));
			const ack = ackBytes ? client.openAck(ackBytes) : null;
			const entries = audit.entries();
			const reason =
				entries.length > before
					? entries[entries.length - 1].reason
					: undefined;
			return { ack, reason };
		},
		sendRawFrame(frame) {
			const before = audit.entries().length;
			const ackBytes = host.handle(frame);
			const ack = ackBytes ? client.openAck(ackBytes) : null;
			const entries = audit.entries();
			const reason =
				entries.length > before
					? entries[entries.length - 1].reason
					: undefined;
			return { ack, reason };
		},
		setKillSwitch(on) {
			host.killSwitch = on;
		},
		auditEntries() {
			return audit.entries();
		},
	};
}
