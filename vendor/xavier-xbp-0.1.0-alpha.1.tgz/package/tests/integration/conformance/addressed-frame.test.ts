import { describe, it } from "vitest";
import {
	addressedFrameChecks,
	createNodeSodiumBackend,
} from "../../../src/index.node.js";

describe("conformance — addressed frame advisory header + fail-closed", () => {
	for (const check of addressedFrameChecks) {
		it(check.name, async () => {
			const backend = await createNodeSodiumBackend();
			check.run(backend);
		});
	}
});
