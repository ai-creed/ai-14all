import { existsSync, readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";
import {
	AntiReplay,
	createNodeSodiumBackend,
	fromHex,
	openAndVerify,
	utf8,
} from "../../../src/index.node.js";

// Drift check for the committed native (Swift) NSE known-answer vectors
// (apps/phone/native/nse/ConformanceVectors.json, produced by
// scripts/generate-nse-vectors.ts). This test rebuilds every case FROM the
// committed keys/ciphertexts so a hand-edit or a regenerate-with-stale-code
// drift is caught here rather than in the Swift XCTests (Task 17) that
// consume the same file.

const HERE = dirname(fileURLToPath(import.meta.url));
const VECTORS_PATH = resolve(
	HERE,
	"../../../../../apps/phone/native/nse/ConformanceVectors.json",
);
const SWIFT_INTEROP_PATH = resolve(
	HERE,
	"../../../../../apps/phone/native/nse/swift-sealed-output.json",
);

interface KeySet {
	signPubHex: string;
	signPrivHex: string;
	boxPubHex: string;
	boxPrivHex: string;
	nodeId: string;
}

interface RequestCase {
	name: "valid-request-roundtrip";
	payloadJson: string;
	sealedHex: string;
	expect: "open-ok";
}

interface RejectSealedCase {
	name: "tampered-ciphertext" | "forged-signature";
	sealedHex: string;
	expect: "reject";
}

interface AckCase {
	name: "replayed-nonce-ack" | "fresh-29s-ack" | "stale-31s-ack";
	ackJson: string;
	priorNonces: string[];
	nowMs: number;
	expect: "accept" | "reject";
}

interface ConformanceVectors {
	protocolVersion: string;
	maxSkewMs: number;
	phone: KeySet;
	host: KeySet;
	cases: (RequestCase | RejectSealedCase | AckCase)[];
}

interface SwiftInteropCase {
	name: string;
	sealedHex: string;
	payloadJson: string;
}

interface SwiftInteropOutput {
	cases: SwiftInteropCase[];
}

const vectors = JSON.parse(
	readFileSync(VECTORS_PATH, "utf8"),
) as ConformanceVectors;

function caseByName(
	name: ConformanceVectors["cases"][number]["name"],
): ConformanceVectors["cases"][number] {
	const found = vectors.cases.find((c) => c.name === name);
	if (!found) {
		throw new Error(`vector case missing: ${name}`);
	}
	return found;
}

describe("NSE conformance vectors — drift check", () => {
	it("maxSkewMs matches AntiReplay's default window", () => {
		expect(vectors.maxSkewMs).toBe(30_000);
	});

	it("valid-request-roundtrip opens and verifies byte-equal to payloadJson", async () => {
		const backend = await createNodeSodiumBackend();
		const kase = caseByName("valid-request-roundtrip") as RequestCase;

		const result = openAndVerify(
			backend,
			fromHex(kase.sealedHex),
			fromHex(vectors.host.boxPubHex),
			fromHex(vectors.host.boxPrivHex),
			fromHex(vectors.phone.signPubHex),
		);

		expect(result.ok).toBe(true);
		if (result.ok) {
			expect(result.payloadBytes).toEqual(utf8(kase.payloadJson));
		}
	});

	it("tampered-ciphertext rejects", async () => {
		const backend = await createNodeSodiumBackend();
		const kase = caseByName("tampered-ciphertext") as RejectSealedCase;

		const result = openAndVerify(
			backend,
			fromHex(kase.sealedHex),
			fromHex(vectors.host.boxPubHex),
			fromHex(vectors.host.boxPrivHex),
			fromHex(vectors.phone.signPubHex),
		);

		expect(result.ok).toBe(false);
	});

	it("forged-signature rejects", async () => {
		const backend = await createNodeSodiumBackend();
		const kase = caseByName("forged-signature") as RejectSealedCase;

		const result = openAndVerify(
			backend,
			fromHex(kase.sealedHex),
			fromHex(vectors.host.boxPubHex),
			fromHex(vectors.host.boxPrivHex),
			fromHex(vectors.phone.signPubHex),
		);

		expect(result.ok).toBe(false);
	});

	it("replayed-nonce-ack rejects once the nonce has already been seen", () => {
		const kase = caseByName("replayed-nonce-ack") as AckCase;
		const replay = new AntiReplay(vectors.maxSkewMs, () => kase.nowMs);
		for (const nonce of kase.priorNonces) {
			expect(replay.check(nonce, kase.nowMs).ok).toBe(true);
		}

		const ack = JSON.parse(kase.ackJson) as { nonce: string; ts: number };
		expect(replay.check(ack.nonce, ack.ts).ok).toBe(false);
	});

	it("fresh-29s-ack accepts (inside the 30s window)", () => {
		const kase = caseByName("fresh-29s-ack") as AckCase;
		const replay = new AntiReplay(vectors.maxSkewMs, () => kase.nowMs);
		for (const nonce of kase.priorNonces) {
			replay.check(nonce, kase.nowMs);
		}

		const ack = JSON.parse(kase.ackJson) as { nonce: string; ts: number };
		expect(replay.check(ack.nonce, ack.ts)).toEqual({ ok: true });
	});

	it("stale-31s-ack rejects (outside the 30s window) — fails a client with a wider window", () => {
		const kase = caseByName("stale-31s-ack") as AckCase;
		const replay = new AntiReplay(vectors.maxSkewMs, () => kase.nowMs);
		for (const nonce of kase.priorNonces) {
			replay.check(nonce, kase.nowMs);
		}

		const ack = JSON.parse(kase.ackJson) as { nonce: string; ts: number };
		expect(replay.check(ack.nonce, ack.ts)).toEqual({
			ok: false,
			reason: "stale-timestamp",
		});
	});

	describe("reverse interop — Swift-sealed output opened by the Node host", () => {
		if (!existsSync(SWIFT_INTEROP_PATH)) {
			if (process.env.NSE_INTEROP === "required") {
				it("fails closed when the artifact is required but missing", () => {
					expect.fail(
						"swift artifact missing — the macOS conformance job must produce it",
					);
				});
			} else {
				it.skip("swift-sealed-output.json not present — skipping (native artifact not produced on this lane)", () => {});
			}
			return;
		}

		const swiftOutput = JSON.parse(
			readFileSync(SWIFT_INTEROP_PATH, "utf8"),
		) as SwiftInteropOutput;

		for (const swiftCase of swiftOutput.cases) {
			it(`opens Swift-sealed case: ${swiftCase.name}`, async () => {
				const backend = await createNodeSodiumBackend();
				const result = openAndVerify(
					backend,
					fromHex(swiftCase.sealedHex),
					fromHex(vectors.host.boxPubHex),
					fromHex(vectors.host.boxPrivHex),
					fromHex(vectors.phone.signPubHex),
				);

				expect(result.ok).toBe(true);
				if (result.ok) {
					expect(result.payloadBytes).toEqual(utf8(swiftCase.payloadJson));
				}
			});
		}
	});
});
