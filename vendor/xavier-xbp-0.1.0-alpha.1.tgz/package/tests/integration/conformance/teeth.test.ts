import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { createReferenceHarness } from "./reference-harness.js";
import {
	conformanceChecks,
	type ConformanceHarness,
	type HarnessFactory,
} from "./suite.js";

describe("conformance suite has teeth", () => {
	let dir: string;

	beforeAll(() => {
		dir = mkdtempSync(join(tmpdir(), "xbp-teeth-"));
	});

	afterAll(() => {
		rmSync(dir, { recursive: true, force: true });
	});

	// A non-conforming implementation: it always grants permissions, ignores the kill
	// switch, and pairs despite an SAS mismatch (alwaysConfirmPairing).
	const brokenFactory: HarnessFactory = async () => {
		const harness = await createReferenceHarness(dir, {
			grantedPermissions: ["hello:invoke"],
			alwaysConfirmPairing: true,
		});
		return { ...harness, setKillSwitch: () => {} } as ConformanceHarness;
	};

	it("fails the kill-switch check against a host that ignores it", async () => {
		const check = conformanceChecks.find((c) => c.name.includes("kill switch"));
		expect(check).toBeDefined();
		await expect(check!.run(brokenFactory)).rejects.toThrow();
	});

	it("fails the permission check against a host that ignores grants", async () => {
		const check = conformanceChecks.find((c) =>
			c.name.includes("insufficient permission"),
		);
		expect(check).toBeDefined();
		await expect(check!.run(brokenFactory)).rejects.toThrow();
	});

	it("fails the SAS-mismatch check against a host that pairs despite a mismatch", async () => {
		const check = conformanceChecks.find((c) =>
			c.name.includes("SAS mismatch"),
		);
		expect(check).toBeDefined();
		await expect(check!.run(brokenFactory)).rejects.toThrow();
	});
});
