import { describe, it } from "vitest";
import {
	backendParityChecks,
	createNodeSodiumBackend,
} from "../../../src/index.node.js";

describe("backend parity — node backend", () => {
	for (const check of backendParityChecks) {
		it(check.name, async () => {
			const backend = await createNodeSodiumBackend();
			check.run(backend);
		});
	}
});
