import assert from "node:assert/strict";
import { describe, it } from "vitest";
import {
	createNodeSodiumBackend,
	fromHex,
	fromUtf8,
	PARITY_VECTORS,
} from "../../../src/index.node.js";
import { RN_INTEROP_VECTOR } from "./rn-interop-fixture.js";

describe("RN → Node sealed-box interop", () => {
	it("the node backend opens a sealed box produced on-device by RnSodiumBackend", async () => {
		if (!RN_INTEROP_VECTOR.sealedHex) {
			console.warn(
				"rn-interop: fixture not yet captured on-device (Task 10) — skipping reverse-direction check",
			);
			return;
		}
		const backend = await createNodeSodiumBackend();
		const opened = backend.open(
			fromHex(RN_INTEROP_VECTOR.sealedHex),
			fromHex(PARITY_VECTORS.seal.publicKeyHex),
			fromHex(PARITY_VECTORS.seal.privateKeyHex),
		);
		assert.notEqual(opened, null);
		assert.equal(fromUtf8(opened!), RN_INTEROP_VECTOR.plaintext);
	});
});
