import { it } from "vitest";
import {
	conformanceChecks,
	type ConformanceHarness,
	type HarnessFactory,
	type PairOutcome,
} from "../../../src/conformance/host-suite.js";

export {
	conformanceChecks,
	type ConformanceHarness,
	type HarnessFactory,
	type PairOutcome,
};

// The vitest `it`-wrapper stays in the test tree so `src` carries no test-runner
// dependency. Downstream hosts iterate `conformanceChecks` themselves.
export function runConformanceSuite(make: HarnessFactory): void {
	for (const check of conformanceChecks) {
		it(check.name, async () => {
			await check.run(make);
		});
	}
}
