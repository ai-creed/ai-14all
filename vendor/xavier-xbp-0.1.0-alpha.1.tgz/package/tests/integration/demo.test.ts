import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import {
	createInMemoryPair,
	createNodeSodiumBackend,
	runDemo,
} from "../../src/index.node.js";

describe("runDemo", () => {
	let dir: string;

	beforeEach(() => {
		dir = mkdtempSync(join(tmpdir(), "xbp-demo-test-"));
	});

	afterEach(() => {
		rmSync(dir, { recursive: true, force: true });
	});

	it("pairs, runs hello, and rejects all three attacks plus the kill switch", async () => {
		const backend = await createNodeSodiumBackend();
		const [hostTransport, clientTransport] = createInMemoryPair();

		const summary = await runDemo({
			hostTransport,
			clientTransport,
			backend,
			auditPath: join(dir, "audit.jsonl"),
		});

		expect(summary.sas.match).toBe(true);

		const byName = Object.fromEntries(
			summary.steps.map((step) => [step.name, step]),
		);
		expect(byName.hello.outcome).toBe("accepted");
		expect(byName.tamper).toMatchObject({
			outcome: "rejected",
			reason: "decrypt-failed",
		});
		expect(byName.forge).toMatchObject({
			outcome: "rejected",
			reason: "bad-signature",
		});
		expect(byName.replay).toMatchObject({
			outcome: "rejected",
			reason: "nonce-reused",
		});
		expect(byName["kill-switch"]).toMatchObject({
			outcome: "rejected",
			reason: "kill-switch",
		});
		expect(
			summary.audit.some(
				(entry) => entry.cap === "pairing" && entry.outcome === "accepted",
			),
		).toBe(true);
		expect(summary.audit.length).toBeGreaterThanOrEqual(6);
	});
});
