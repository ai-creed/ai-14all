import { describe, expect, it } from "vitest";
import { z } from "zod";
import { defineCapability } from "@ai-creed/command-contract";
import {
	createInMemoryPair,
	createNodeSodiumBackend,
	deriveNodeId,
	generateIdentity,
	Peer,
	PeerCallError,
	type Transport,
} from "../../src/index.node.js";

const echoCap = defineCapability({
	id: "xavier.control.echo",
	title: "Echo",
	args: z.object({ text: z.string() }),
	result: z.object({ text: z.string() }),
	risk: "low",
	permission: "control:read",
});

async function pair() {
	const backend = await createNodeSodiumBackend();
	const hostId = generateIdentity(backend);
	const phoneId = generateIdentity(backend);
	const [hostT, phoneT]: [Transport, Transport] = createInMemoryPair();

	const host = new Peer({ backend, identity: hostId, transport: hostT });
	const phone = new Peer({
		backend,
		identity: phoneId,
		transport: phoneT,
		requestTimeoutMs: 500,
	});
	const phoneNode = host.addPeer(
		phoneId.sign.publicKey,
		phoneId.box.publicKey,
		["control:read"],
	);
	const hostNode = phone.addPeer(
		hostId.sign.publicKey,
		hostId.box.publicKey,
		[],
	);
	host.start();
	phone.start();
	return { backend, host, phone, hostId, phoneId, hostNode, phoneNode };
}

describe("Peer request/ack", () => {
	it("derives a stable nodeId matching deriveNodeId", async () => {
		const { backend, host, hostId } = await pair();
		expect(host.nodeId).toBe(deriveNodeId(backend, hostId.sign.publicKey));
	});

	it("round-trips a call through expose → handler → ack", async () => {
		const { host, phone, hostNode } = await pair();
		host.expose(echoCap, (args) => ({ text: args.text.toUpperCase() }));
		const result = await phone.call(hostNode, echoCap, { text: "hi" });
		expect(result).toEqual({ text: "HI" });
	});

	it("rejects an unknown capability with an error ack", async () => {
		const { phone, hostNode } = await pair();
		// host exposes nothing
		await expect(phone.call(hostNode, echoCap, { text: "hi" })).rejects.toThrow(
			PeerCallError,
		);
	});

	it("rejects when the caller lacks the capability permission", async () => {
		const backend = await createNodeSodiumBackend();
		const hostId = generateIdentity(backend);
		const phoneId = generateIdentity(backend);
		const [hostT, phoneT]: [Transport, Transport] = createInMemoryPair();
		const host = new Peer({ backend, identity: hostId, transport: hostT });
		const phone = new Peer({
			backend,
			identity: phoneId,
			transport: phoneT,
			requestTimeoutMs: 500,
		});
		// grant NO permissions to the phone
		host.addPeer(phoneId.sign.publicKey, phoneId.box.publicKey, []);
		const hostNode = phone.addPeer(hostId.sign.publicKey, hostId.box.publicKey, []);
		host.expose(echoCap, (args) => ({ text: args.text }));
		host.start();
		phone.start();
		await expect(
			phone.call(hostNode, echoCap, { text: "hi" }),
		).rejects.toMatchObject({ code: "permission-denied" });
	});

	it("times out when calling an unknown peer is impossible (guards locally)", async () => {
		const { phone } = await pair();
		await expect(
			phone.call("ffffffffffffffffffffffffffffffff", echoCap, { text: "hi" }),
		).rejects.toMatchObject({ code: "unknown-peer" });
	});
});

describe("Peer events", () => {
	it("delivers an emitted event to a subscribed peer with the sender nodeId", async () => {
		const { host, phone, phoneNode } = await pair();
		const received: Array<{ from: string; topic: string; payload: unknown }> = [];
		phone.onEvent((from, topic, payload) =>
			received.push({ from, topic, payload }),
		);
		host.emit(phoneNode, "xavier.control.session-changed", { worktreeId: "wt-1" });
		await new Promise((r) => setTimeout(r, 20));
		expect(received).toHaveLength(1);
		expect(received[0].topic).toBe("xavier.control.session-changed");
		expect(received[0].payload).toEqual({ worktreeId: "wt-1" });
		expect(received[0].from).toBe(host.nodeId);
	});

	it("unsubscribes cleanly", async () => {
		const { host, phone, phoneNode } = await pair();
		let count = 0;
		const off = phone.onEvent(() => (count += 1));
		off();
		host.emit(phoneNode, "xavier.control.session-changed", {});
		await new Promise((r) => setTimeout(r, 20));
		expect(count).toBe(0);
	});
});
