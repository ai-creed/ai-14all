import { describe, expect, it } from "vitest";
import {
	createNodeSodiumBackend,
	openAndVerify,
	sealAndSign,
	utf8,
} from "../../../src/index.node.js";

async function fixture() {
	const backend = await createNodeSodiumBackend();
	const sender = {
		sign: backend.generateSignKeyPair(),
		box: backend.generateBoxKeyPair(),
	};
	const recipient = {
		sign: backend.generateSignKeyPair(),
		box: backend.generateBoxKeyPair(),
	};
	const payload = utf8("hello world");
	return { backend, sender, recipient, payload };
}

describe("envelope", () => {
	it("round-trips a sealed, signed payload", async () => {
		const { backend, sender, recipient, payload } = await fixture();
		const sealed = sealAndSign(
			backend,
			payload,
			sender.sign.privateKey,
			recipient.box.publicKey,
		);

		const result = openAndVerify(
			backend,
			sealed,
			recipient.box.publicKey,
			recipient.box.privateKey,
			sender.sign.publicKey,
		);

		expect(result.ok).toBe(true);
		if (result.ok) {
			expect(result.payloadBytes).toEqual(payload);
		}
	});

	it("rejects a tampered ciphertext (decrypt-failed)", async () => {
		const { backend, sender, recipient, payload } = await fixture();
		const sealed = sealAndSign(
			backend,
			payload,
			sender.sign.privateKey,
			recipient.box.publicKey,
		);
		sealed[0] ^= 0xff;

		const result = openAndVerify(
			backend,
			sealed,
			recipient.box.publicKey,
			recipient.box.privateKey,
			sender.sign.publicKey,
		);

		expect(result).toEqual({ ok: false, reason: "decrypt-failed" });
	});

	it("rejects a forged signature (bad-signature)", async () => {
		const { backend, sender, recipient, payload } = await fixture();
		const wrongSigner = backend.generateSignKeyPair();
		const sealed = sealAndSign(
			backend,
			payload,
			wrongSigner.privateKey,
			recipient.box.publicKey,
		);

		const result = openAndVerify(
			backend,
			sealed,
			recipient.box.publicKey,
			recipient.box.privateKey,
			sender.sign.publicKey,
		);

		expect(result).toEqual({ ok: false, reason: "bad-signature" });
	});

	it("rejects a wrong-length signature without throwing (bad-signature)", async () => {
		const { backend, sender, recipient } = await fixture();
		const inner = JSON.stringify({ p: "00", s: "00" });
		const sealed = backend.seal(utf8(inner), recipient.box.publicKey);

		const result = openAndVerify(
			backend,
			sealed,
			recipient.box.publicKey,
			recipient.box.privateKey,
			sender.sign.publicKey,
		);

		expect(result).toEqual({ ok: false, reason: "bad-signature" });
	});

	it("rejects the wrong recipient (decrypt-failed)", async () => {
		const { backend, sender, payload } = await fixture();
		const intended = { box: backend.generateBoxKeyPair() };
		const stranger = { box: backend.generateBoxKeyPair() };
		const sealed = sealAndSign(
			backend,
			payload,
			sender.sign.privateKey,
			intended.box.publicKey,
		);

		const result = openAndVerify(
			backend,
			sealed,
			stranger.box.publicKey,
			stranger.box.privateKey,
			sender.sign.publicKey,
		);

		expect(result).toEqual({ ok: false, reason: "decrypt-failed" });
	});
});
