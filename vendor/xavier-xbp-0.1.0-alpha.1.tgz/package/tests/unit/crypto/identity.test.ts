import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import {
	createNodeSodiumBackend,
	generateIdentity,
	loadIdentity,
	saveIdentity,
} from "../../../src/index.node.js";

describe("identity", () => {
	let dir: string;

	beforeEach(() => {
		dir = mkdtempSync(join(tmpdir(), "xbp-id-"));
	});

	afterEach(() => {
		rmSync(dir, { recursive: true, force: true });
	});

	it("generates distinct sign and box keypairs", async () => {
		const backend = await createNodeSodiumBackend();
		const identity = generateIdentity(backend);

		expect(identity.sign.publicKey.length).toBeGreaterThan(0);
		expect(identity.box.publicKey.length).toBeGreaterThan(0);
		expect(identity.sign.publicKey).not.toEqual(identity.box.publicKey);
	});

	it("round-trips through save and load", async () => {
		const backend = await createNodeSodiumBackend();
		const identity = generateIdentity(backend);
		const path = join(dir, "identity.json");

		saveIdentity(path, identity);
		const loaded = loadIdentity(path);

		expect(loaded.sign.publicKey).toEqual(identity.sign.publicKey);
		expect(loaded.sign.privateKey).toEqual(identity.sign.privateKey);
		expect(loaded.box.publicKey).toEqual(identity.box.publicKey);
		expect(loaded.box.privateKey).toEqual(identity.box.privateKey);
	});
});
