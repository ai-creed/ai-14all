import { describe, expect, it } from "vitest";
import {
	computeSAS,
	createNodeSodiumBackend,
} from "../../../src/index.node.js";

describe("computeSAS", () => {
	it("matches regardless of argument order and is 6 digits", async () => {
		const backend = await createNodeSodiumBackend();
		const a = {
			sign: backend.generateSignKeyPair(),
			box: backend.generateBoxKeyPair(),
		};
		const b = {
			sign: backend.generateSignKeyPair(),
			box: backend.generateBoxKeyPair(),
		};

		const fromA = computeSAS(
			backend,
			a.sign.publicKey,
			a.box.publicKey,
			b.sign.publicKey,
			b.box.publicKey,
		);
		const fromB = computeSAS(
			backend,
			b.sign.publicKey,
			b.box.publicKey,
			a.sign.publicKey,
			a.box.publicKey,
		);

		expect(fromA).toBe(fromB);
		expect(fromA).toMatch(/^\d{6}$/);
	});

	it("differs when a key is substituted (MITM)", async () => {
		const backend = await createNodeSodiumBackend();
		const a = {
			sign: backend.generateSignKeyPair(),
			box: backend.generateBoxKeyPair(),
		};
		const b = {
			sign: backend.generateSignKeyPair(),
			box: backend.generateBoxKeyPair(),
		};
		const attacker = backend.generateBoxKeyPair();

		const honest = computeSAS(
			backend,
			a.sign.publicKey,
			a.box.publicKey,
			b.sign.publicKey,
			b.box.publicKey,
		);
		const mitm = computeSAS(
			backend,
			a.sign.publicKey,
			a.box.publicKey,
			b.sign.publicKey,
			attacker.publicKey,
		);

		expect(mitm).not.toBe(honest);
	});
});
