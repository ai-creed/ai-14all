import { describe, expect, it } from "vitest";
import { createNodeSodiumBackend } from "../../../src/index.node.js";

describe("node sodium backend", () => {
	it("signs and verifies, rejecting a bad signature", async () => {
		const sodium = await createNodeSodiumBackend();
		const keys = sodium.generateSignKeyPair();
		const message = new Uint8Array([1, 2, 3]);
		const signature = sodium.sign(message, keys.privateKey);

		expect(sodium.verify(message, signature, keys.publicKey)).toBe(true);

		const tampered = new Uint8Array(message);
		tampered[0] ^= 0xff;
		expect(sodium.verify(tampered, signature, keys.publicKey)).toBe(false);
	});

	it("seals and opens, returning null on the wrong recipient", async () => {
		const sodium = await createNodeSodiumBackend();
		const recipient = sodium.generateBoxKeyPair();
		const stranger = sodium.generateBoxKeyPair();
		const message = new Uint8Array([9, 8, 7]);
		const sealed = sodium.seal(message, recipient.publicKey);

		expect(
			sodium.open(sealed, recipient.publicKey, recipient.privateKey),
		).toEqual(message);
		expect(
			sodium.open(sealed, stranger.publicKey, stranger.privateKey),
		).toBeNull();
	});
});
