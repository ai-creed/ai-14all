import { describe, expect, it } from "vitest";
import {
	createNodeSodiumBackend,
	deriveNodeId,
	generateIdentity,
} from "../../../src/index.node.js";

describe("deriveNodeId", () => {
	it("is a deterministic 32-hex fingerprint of the sign public key", async () => {
		const backend = await createNodeSodiumBackend();
		const id = generateIdentity(backend);
		const a = deriveNodeId(backend, id.sign.publicKey);
		const b = deriveNodeId(backend, id.sign.publicKey);
		expect(a).toBe(b);
		expect(a).toMatch(/^[0-9a-f]{32}$/);
	});

	it("differs for different keys and ignores the box key", async () => {
		const backend = await createNodeSodiumBackend();
		const one = generateIdentity(backend);
		const two = generateIdentity(backend);
		expect(deriveNodeId(backend, one.sign.publicKey)).not.toBe(
			deriveNodeId(backend, two.sign.publicKey),
		);
	});
});
