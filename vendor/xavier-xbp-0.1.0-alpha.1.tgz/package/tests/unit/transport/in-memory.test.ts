import { describe, expect, it } from "vitest";
import { createInMemoryPair } from "../../../src/index.node.js";

describe("in-memory transport", () => {
	it("delivers a frame from one end to the other", async () => {
		const [a, b] = createInMemoryPair();
		const received: string[] = [];
		b.onFrame((frame) => received.push(new TextDecoder().decode(frame)));

		await a.send(new TextEncoder().encode("ping"));
		await new Promise((resolve) => setTimeout(resolve, 0));

		expect(received).toEqual(["ping"]);
	});

	it("stops delivering after unsubscribe", async () => {
		const [a, b] = createInMemoryPair();
		const received: string[] = [];
		const off = b.onFrame((frame) =>
			received.push(new TextDecoder().decode(frame)),
		);
		off();

		await a.send(new TextEncoder().encode("ping"));
		await new Promise((resolve) => setTimeout(resolve, 0));

		expect(received).toEqual([]);
	});

	it("does not deliver after close", async () => {
		const [a, b] = createInMemoryPair();
		const received: string[] = [];
		b.onFrame((frame) => received.push(new TextDecoder().decode(frame)));
		await b.close();

		await a.send(new TextEncoder().encode("ping"));
		await new Promise((resolve) => setTimeout(resolve, 0));

		expect(received).toEqual([]);
	});
});

// onClose means "the link died on us", never "we hung up". The distinction is
// load-bearing: the phone tears its session down and reconnects when it hears
// this, so a deliberate close (its own panic/Disconnect) firing it would
// resurrect the session the user just dropped.
describe("in-memory transport onClose", () => {
	it("fires the surviving end's handlers when its peer closes", async () => {
		const [a, b] = createInMemoryPair();
		let lost = 0;
		b.onClose?.(() => {
			lost += 1;
		});

		await a.close();

		expect(lost).toBe(1);
	});

	it("does not fire the closing end's own handlers", async () => {
		const [a, b] = createInMemoryPair();
		let aLost = 0;
		let bLost = 0;
		a.onClose?.(() => {
			aLost += 1;
		});
		b.onClose?.(() => {
			bLost += 1;
		});

		await a.close();

		expect(aLost).toBe(0);
		expect(bLost).toBe(1);
	});

	it("fires at most once even if close is called repeatedly", async () => {
		const [a, b] = createInMemoryPair();
		let lost = 0;
		b.onClose?.(() => {
			lost += 1;
		});

		await a.close();
		await a.close();

		expect(lost).toBe(1);
	});

	it("unsubscribe removes only its own handler", async () => {
		const [a, b] = createInMemoryPair();
		const fired: string[] = [];
		const off = b.onClose?.(() => fired.push("first"));
		b.onClose?.(() => fired.push("second"));
		off?.();

		await a.close();

		expect(fired).toEqual(["second"]);
	});
});
