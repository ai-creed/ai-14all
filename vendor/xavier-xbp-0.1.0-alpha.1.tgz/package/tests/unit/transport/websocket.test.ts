import { afterEach, describe, expect, it } from "vitest";
import {
	connectWebSocketClient,
	startWebSocketHost,
	type Transport,
	type WebSocketHost,
} from "../../../src/index.node.js";

describe("websocket transport", () => {
	let host: WebSocketHost | null = null;
	let client: Transport | null = null;

	afterEach(async () => {
		await client?.close();
		await host?.close();
		host = null;
		client = null;
	});

	it("exchanges a frame over localhost", async () => {
		host = await startWebSocketHost(0);
		const connectionPromise = host.nextConnection();
		client = await connectWebSocketClient(`ws://127.0.0.1:${host.port}`);
		const serverSide = await connectionPromise;

		const received: string[] = [];
		serverSide.onFrame((frame) =>
			received.push(new TextDecoder().decode(frame)),
		);
		await client.send(new TextEncoder().encode("over-the-wire"));
		await new Promise((resolve) => setTimeout(resolve, 50));

		expect(received).toEqual(["over-the-wire"]);
	});

	it("accepts a connection when an explicit loopback host is supplied", async () => {
		const wsHost = await startWebSocketHost(0, "127.0.0.1");
		const connectionPromise = wsHost.nextConnection();
		const client = await connectWebSocketClient(`ws://127.0.0.1:${wsHost.port}`);
		const server = await connectionPromise;

		const received: Uint8Array[] = [];
		server.onFrame((frame) => received.push(frame));
		await client.send(new Uint8Array([7, 8, 9]));
		await new Promise((resolve) => setTimeout(resolve, 20));

		expect(received[0]).toEqual(new Uint8Array([7, 8, 9]));

		await client.close();
		await server.close();
		await wsHost.close();
	});
});
