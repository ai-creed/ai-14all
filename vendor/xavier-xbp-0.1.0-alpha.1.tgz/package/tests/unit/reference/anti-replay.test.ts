import { describe, expect, it } from "vitest";
import { AntiReplay } from "../../../src/index.node.js";

describe("AntiReplay", () => {
	it("accepts a fresh nonce within the window", () => {
		const replay = new AntiReplay(30_000, () => 1_000_000);
		expect(replay.check("nonce-a", 1_000_000)).toEqual({ ok: true });
	});

	it("rejects a reused nonce", () => {
		const replay = new AntiReplay(30_000, () => 1_000_000);
		replay.check("nonce-a", 1_000_000);
		expect(replay.check("nonce-a", 1_000_000)).toEqual({
			ok: false,
			reason: "nonce-reused",
		});
	});

	it("rejects a stale timestamp", () => {
		const replay = new AntiReplay(30_000, () => 1_000_000);
		expect(replay.check("nonce-b", 900_000)).toEqual({
			ok: false,
			reason: "stale-timestamp",
		});
	});
});
