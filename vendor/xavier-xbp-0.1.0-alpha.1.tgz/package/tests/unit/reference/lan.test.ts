import { describe, expect, it } from "vitest";
import { getLanAddress } from "../../../src/index.node.js";

describe("getLanAddress", () => {
	it("returns the first non-internal IPv4 address", () => {
		const fake = {
			lo0: [{ address: "127.0.0.1", family: "IPv4", internal: true }],
			en0: [
				{ address: "fe80::1", family: "IPv6", internal: false },
				{ address: "192.168.1.42", family: "IPv4", internal: false },
			],
		};
		expect(getLanAddress(fake as never)).toBe("192.168.1.42");
	});

	it("returns null when only internal interfaces exist", () => {
		const fake = {
			lo0: [{ address: "127.0.0.1", family: "IPv4", internal: true }],
		};
		expect(getLanAddress(fake as never)).toBeNull();
	});
});
