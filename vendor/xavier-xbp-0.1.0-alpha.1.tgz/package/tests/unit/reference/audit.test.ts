import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { AuditLog } from "../../../src/index.node.js";

describe("AuditLog", () => {
	let dir: string;

	beforeEach(() => {
		dir = mkdtempSync(join(tmpdir(), "xbp-audit-"));
	});

	afterEach(() => {
		rmSync(dir, { recursive: true, force: true });
	});

	it("appends entries and reads them back as JSON lines", () => {
		const log = new AuditLog(join(dir, "audit.jsonl"), () => 42);
		log.append({ cap: "hello", risk: "low", outcome: "accepted" });
		log.append({
			cap: "hello",
			risk: "low",
			outcome: "rejected",
			reason: "bad-signature",
		});

		const entries = log.entries();
		expect(entries).toEqual([
			{ ts: 42, cap: "hello", risk: "low", outcome: "accepted" },
			{
				ts: 42,
				cap: "hello",
				risk: "low",
				outcome: "rejected",
				reason: "bad-signature",
			},
		]);
	});

	it("returns an empty array when nothing has been written", () => {
		const log = new AuditLog(join(dir, "missing.jsonl"));
		expect(log.entries()).toEqual([]);
	});
});
