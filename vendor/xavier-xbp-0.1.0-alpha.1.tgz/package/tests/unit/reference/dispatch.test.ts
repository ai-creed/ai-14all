import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { z } from "zod";
import {
	AntiReplay,
	AuditLog,
	CapabilityRegistry,
	createNodeSodiumBackend,
	decodeFrame,
	defineCapability,
	generateIdentity,
	helloCapability,
	PairAccept,
	ReferenceClient,
	ReferenceHost,
} from "../../../src/index.node.js";

async function setup(dir: string, grantedPermissions?: string[]) {
	const backend = await createNodeSodiumBackend();
	const registry = new CapabilityRegistry();
	registry.register(helloCapability);
	registry.register(
		defineCapability({
			id: "noop",
			schema: z.object({}),
			risk: "low",
			permission: "hello:invoke",
		}),
	);
	const audit = new AuditLog(join(dir, "audit.jsonl"));
	const host = new ReferenceHost({
		backend,
		identity: generateIdentity(backend),
		registry,
		antiReplay: new AntiReplay(),
		audit,
		handlers: {
			hello: (params) => ({
				youSaid: (params as { greeting: string }).greeting,
			}),
		},
		grantedPermissions,
	});
	const client = new ReferenceClient({
		backend,
		identity: generateIdentity(backend),
	});
	const offer = host.createPairingOffer();
	const accept = PairAccept.parse(
		decodeFrame(host.handle(client.buildPairRequest(offer.token))!),
	);
	const clientSas = client.acceptPairResponse(accept, offer);
	// Keys stay pending until the SAS is confirmed; this is an honest pairing, so confirm
	// the match on both ends. Without this the client cannot build requests (hostBoxPub is
	// null) and every dispatch assertion below would throw before exercising the host.
	const match = clientSas === host.lastSas;
	host.confirmPairing(match);
	client.confirmPairing(match);
	return { backend, host, client, audit };
}

function lastReason(audit: AuditLog): string | undefined {
	const entries = audit.entries();
	return entries[entries.length - 1]?.reason;
}

describe("fail-closed dispatch", () => {
	let dir: string;

	beforeEach(() => {
		dir = mkdtempSync(join(tmpdir(), "xbp-dispatch-"));
	});

	afterEach(() => {
		rmSync(dir, { recursive: true, force: true });
	});

	it("rejects an unsupported version", async () => {
		const { host, client, audit } = await setup(dir);
		expect(
			host.handle(
				client.buildRequest("hello", { greeting: "hi" }, { version: "xbp/0" }),
			),
		).toBeNull();
		expect(lastReason(audit)).toBe("unsupported-version");
	});

	it("rejects a reused nonce", async () => {
		const { host, client, audit } = await setup(dir);
		host.handle(
			client.buildRequest("hello", { greeting: "hi" }, { nonce: "fixed" }),
		);
		expect(
			host.handle(
				client.buildRequest("hello", { greeting: "hi" }, { nonce: "fixed" }),
			),
		).toBeNull();
		expect(lastReason(audit)).toBe("nonce-reused");
	});

	it("rejects a stale timestamp", async () => {
		const { host, client, audit } = await setup(dir);
		expect(
			host.handle(client.buildRequest("hello", { greeting: "hi" }, { ts: 1 })),
		).toBeNull();
		expect(lastReason(audit)).toBe("stale-timestamp");
	});

	it("rejects an unknown capability", async () => {
		const { host, client, audit } = await setup(dir);
		expect(host.handle(client.buildRequest("ghost", {}))).toBeNull();
		expect(lastReason(audit)).toBe("unknown-capability");
	});

	it("rejects schema-invalid params", async () => {
		const { host, client, audit } = await setup(dir);
		expect(
			host.handle(client.buildRequest("hello", { greeting: 123 })),
		).toBeNull();
		expect(lastReason(audit)).toBe("schema-invalid");
	});

	it("rejects insufficient permission", async () => {
		const { host, client, audit } = await setup(dir, []);
		expect(
			host.handle(client.buildRequest("hello", { greeting: "hi" })),
		).toBeNull();
		expect(lastReason(audit)).toBe("permission-denied");
	});

	it("rejects a forged signature", async () => {
		const { backend, host, client, audit } = await setup(dir);
		const wrong = backend.generateSignKeyPair();
		expect(
			host.handle(
				client.buildRequest(
					"hello",
					{ greeting: "hi" },
					{ signPrivateKeyOverride: wrong.privateKey },
				),
			),
		).toBeNull();
		expect(lastReason(audit)).toBe("bad-signature");
	});

	it("rejects a tampered ciphertext", async () => {
		const { host, client, audit } = await setup(dir);
		expect(
			host.handle(
				client.buildRequest("hello", { greeting: "hi" }, { tamper: true }),
			),
		).toBeNull();
		expect(lastReason(audit)).toBe("decrypt-failed");
	});

	it("rejects a wrong-recipient envelope", async () => {
		const { backend, host, client, audit } = await setup(dir);
		const stranger = backend.generateBoxKeyPair();
		expect(
			host.handle(
				client.buildRequest(
					"hello",
					{ greeting: "hi" },
					{ recipientBoxPubOverride: stranger.publicKey },
				),
			),
		).toBeNull();
		expect(lastReason(audit)).toBe("decrypt-failed");
	});

	it("halts all requests when the kill switch is on", async () => {
		const { host, client, audit } = await setup(dir);
		host.killSwitch = true;
		expect(
			host.handle(client.buildRequest("hello", { greeting: "hi" })),
		).toBeNull();
		expect(lastReason(audit)).toBe("kill-switch");
	});

	it("records the capability risk on an accepted request", async () => {
		const { host, client, audit } = await setup(dir);
		host.handle(client.buildRequest("hello", { greeting: "hi" }));
		const accepted = audit
			.entries()
			.filter((entry) => entry.outcome === "accepted");
		expect(accepted.at(-1)).toMatchObject({
			cap: "hello",
			risk: "low",
			outcome: "accepted",
		});
	});
});
