import { readFileSync } from "node:fs";
import { builtinModules } from "node:module";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";
import {
	createNodeSodiumBackend,
	ReferenceHost,
	runDemo,
	saveIdentity,
	startWebSocketHost,
} from "../../src/index.node.js";
import {
	backendParityChecks,
	parsePairingOffer,
	ReferenceClient,
} from "../../src/index.js";

// The platform-neutral entry must be bundleable by Metro (React Native): its
// transitive import graph may not reach any Node built-in — whether prefixed
// (`node:fs`) or bare (`fs`, `module`; bare `module` is the only source of
// `createRequire`) — nor `ws` or `libsodium-wrappers` (including subpaths).
// This static walk enforces that contract so the 0b.1b phone build cannot
// regress. It assumes house style: every relative import uses an explicit
// `.js` extension and points at a single file.

const HERE = dirname(fileURLToPath(import.meta.url));
const SRC = resolve(HERE, "../../src");
const NEUTRAL_ENTRY = resolve(SRC, "index.ts");

const NODE_BUILTINS = new Set(builtinModules);
// Bare packages that must never appear in the neutral graph — matched as the
// exact name or any subpath (e.g. `libsodium-wrappers/sumo`).
const FORBIDDEN_PACKAGES = ["ws", "libsodium-wrappers"];

function isForbidden(spec: string): boolean {
	if (spec.startsWith("node:")) {
		return true;
	}
	if (NODE_BUILTINS.has(spec.split("/")[0])) {
		return true;
	}
	return FORBIDDEN_PACKAGES.some(
		(pkg) => spec === pkg || spec.startsWith(`${pkg}/`),
	);
}

// Capture every import specifier: static `from` clauses, side-effect imports
// (`import "node:fs";`), dynamic `import("...")`, and `require("...")`.
function importsOf(source: string): string[] {
	const specs: string[] = [];
	const re = /(?:\bfrom\s*|\bimport\s*\(\s*|\brequire\s*\(\s*|\bimport\s+)["']([^"']+)["']/g;
	let match: RegExpExecArray | null;
	while ((match = re.exec(source)) !== null) {
		specs.push(match[1]);
	}
	return specs;
}

function resolveRelative(fromFile: string, spec: string): string {
	return resolve(dirname(fromFile), spec).replace(/\.js$/, ".ts");
}

function collectForbidden(entry: string): string[] {
	const seen = new Set<string>();
	const violations: string[] = [];
	const stack = [entry];
	while (stack.length > 0) {
		const file = stack.pop();
		if (file === undefined || seen.has(file)) {
			continue;
		}
		seen.add(file);
		for (const spec of importsOf(readFileSync(file, "utf8"))) {
			if (isForbidden(spec)) {
				violations.push(`${file} -> ${spec}`);
			} else if (spec.startsWith(".")) {
				stack.push(resolveRelative(file, spec));
			}
		}
	}
	return violations;
}

describe("platform-neutral entry import graph", () => {
	it("reaches no Node builtin, ws, or libsodium-wrappers", () => {
		expect(collectForbidden(NEUTRAL_ENTRY)).toEqual([]);
	});

	it("the node entry surfaces the backend, transport, store, reference, and demo", () => {
		expect(typeof createNodeSodiumBackend).toBe("function");
		expect(typeof startWebSocketHost).toBe("function");
		expect(typeof saveIdentity).toBe("function");
		expect(typeof ReferenceHost).toBe("function");
		expect(typeof runDemo).toBe("function");
	});

	it("the neutral entry surfaces the client and offer parser the phone needs", () => {
		expect(typeof ReferenceClient).toBe("function");
		expect(typeof parsePairingOffer).toBe("function");
		expect(Array.isArray(backendParityChecks)).toBe(true);
	});
});
