import { describe, expect, it } from "vitest";
import { parsePairingOffer } from "../../src/protocol/pairing.js";

const base = {
	token: "t0",
	signPubHex: "aa",
	boxPubHex: "bb",
	expiresAt: 123,
};

describe("PairingOffer.connect urls", () => {
	it("accepts an ordered non-empty url list", () => {
		const offer = parsePairingOffer(
			JSON.stringify({ ...base, connect: { urls: ["ws://10.0.0.2:4600", "wss://r.example/connect/ff"] } }),
		);
		expect(offer?.connect.urls).toEqual(["ws://10.0.0.2:4600", "wss://r.example/connect/ff"]);
	});

	it("rejects an empty url list", () => {
		expect(parsePairingOffer(JSON.stringify({ ...base, connect: { urls: [] } }))).toBeNull();
	});

	it("rejects the legacy single-url shape (clean break, no dual parsing)", () => {
		expect(
			parsePairingOffer(JSON.stringify({ ...base, connect: { url: "ws://10.0.0.2:4600" } })),
		).toBeNull();
	});
});
