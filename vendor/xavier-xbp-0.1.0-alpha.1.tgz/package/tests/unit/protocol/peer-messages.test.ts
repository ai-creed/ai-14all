import { describe, expect, it } from "vitest";
import { PeerMessage } from "../../../src/protocol/peer-messages.js";
import { PROTOCOL_VERSION } from "../../../src/protocol/version.js";

describe("PeerMessage", () => {
	it("parses a request", () => {
		const parsed = PeerMessage.safeParse({
			v: PROTOCOL_VERSION,
			kind: "request",
			requestId: "r1",
			capabilityId: "xavier.control.session-report",
			args: {},
			nonce: "ab",
			ts: 1,
		});
		expect(parsed.success).toBe(true);
	});

	it("parses a valid ok ack and a valid error ack", () => {
		expect(
			PeerMessage.safeParse({
				v: PROTOCOL_VERSION,
				kind: "ack",
				requestId: "r1",
				ok: true,
				result: { sessions: [] },
				nonce: "ab",
				ts: 1,
			}).success,
		).toBe(true);
		expect(
			PeerMessage.safeParse({
				v: PROTOCOL_VERSION,
				kind: "ack",
				requestId: "r1",
				ok: false,
				error: { code: "permission-denied", message: "permission-denied" },
				nonce: "ab",
				ts: 1,
			}).success,
		).toBe(true);
	});

	it("rejects malformed acks that violate the ok/result vs ok/error union", () => {
		const base = {
			v: PROTOCOL_VERSION,
			kind: "ack",
			requestId: "r1",
			nonce: "ab",
			ts: 1,
		};
		// ok:false with no error
		expect(PeerMessage.safeParse({ ...base, ok: false }).success).toBe(false);
		// ok:true with no result
		expect(PeerMessage.safeParse({ ...base, ok: true }).success).toBe(false);
		// ok:true with an explicit undefined result (the zod-4 refine must still reject)
		expect(
			PeerMessage.safeParse({ ...base, ok: true, result: undefined }).success,
		).toBe(false);
		// ok:false carrying a result instead of an error
		expect(
			PeerMessage.safeParse({ ...base, ok: false, result: { sessions: [] } })
				.success,
		).toBe(false);
		// non-boolean ok
		expect(PeerMessage.safeParse({ ...base, ok: "yes" }).success).toBe(false);
	});

	it("parses an event and rejects an unknown kind", () => {
		expect(
			PeerMessage.safeParse({
				v: PROTOCOL_VERSION,
				kind: "event",
				topic: "xavier.control.session-changed",
				payload: { worktreeId: "wt-1" },
				nonce: "ab",
				ts: 1,
			}).success,
		).toBe(true);
		expect(PeerMessage.safeParse({ kind: "nope" }).success).toBe(false);
	});
});
