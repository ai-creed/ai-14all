import { describe, expect, it } from "vitest";
import {
	AckPayload,
	decodeFrame,
	encodeFrame,
	isSupportedVersion,
	PROTOCOL_VERSION,
	RequestPayload,
	utf8,
} from "../../../src/index.node.js";

describe("version", () => {
	it("recognizes the supported version and nothing else", () => {
		expect(isSupportedVersion(PROTOCOL_VERSION)).toBe(true);
		expect(isSupportedVersion("xbp/0")).toBe(false);
		expect(isSupportedVersion(undefined)).toBe(false);
	});
});

describe("messages", () => {
	it("requires a version on a request payload", () => {
		expect(
			RequestPayload.safeParse({ cap: "hello", params: {}, nonce: "ab", ts: 1 })
				.success,
		).toBe(false);
		expect(
			RequestPayload.safeParse({
				v: "xbp/1",
				cap: "hello",
				params: {},
				nonce: "ab",
				ts: 1,
			}).success,
		).toBe(true);
	});

	it("validates an ack payload", () => {
		expect(
			AckPayload.safeParse({
				v: "xbp/1",
				ok: true,
				cap: "hello",
				nonce: "ab",
				ts: 1,
			}).success,
		).toBe(true);
	});
});

describe("wire frames", () => {
	it("round-trips a sealed frame", () => {
		const frame = {
			t: "sealed",
			v: PROTOCOL_VERSION,
			boxHex: "deadbeef",
		} as const;
		const decoded = decodeFrame(encodeFrame(frame));
		expect(decoded).toEqual(frame);
	});

	it("returns null for an unknown frame type", () => {
		expect(
			decodeFrame(utf8(JSON.stringify({ t: "nope", v: PROTOCOL_VERSION }))),
		).toBeNull();
	});

	it("returns null for a frame missing its version", () => {
		expect(
			decodeFrame(utf8(JSON.stringify({ t: "sealed", boxHex: "deadbeef" }))),
		).toBeNull();
	});

	it("returns null for a frame with an unsupported version", () => {
		expect(
			decodeFrame(
				utf8(JSON.stringify({ t: "sealed", v: "xbp/0", boxHex: "deadbeef" })),
			),
		).toBeNull();
	});

	it("returns null for non-JSON bytes", () => {
		expect(decodeFrame(utf8("{not json"))).toBeNull();
	});

	it("round-trips an addressed frame and keeps it distinct from sealed", () => {
		const frame = encodeFrame({
			t: "addressed",
			v: PROTOCOL_VERSION,
			to: "aabbccddeeff00112233445566778899",
			from: "99887766554433221100ffeeddccbbaa",
			payload: "deadbeef",
		});
		const decoded = decodeFrame(frame);
		expect(decoded?.t).toBe("addressed");
		if (decoded?.t === "addressed") {
			expect(decoded.to).toBe("aabbccddeeff00112233445566778899");
			expect(decoded.from).toBe("99887766554433221100ffeeddccbbaa");
			expect(decoded.payload).toBe("deadbeef");
		}
	});

	it("rejects an addressed frame missing the routing header", () => {
		const bytes = utf8(JSON.stringify({ t: "addressed", v: PROTOCOL_VERSION, payload: "ab" }));
		expect(decodeFrame(bytes)).toBeNull();
	});
});
