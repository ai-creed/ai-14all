import { describe, expect, it } from "vitest";
import { z } from "zod";
import {
	CapabilityRegistry,
	defineCapability,
	helloCapability,
} from "../../../src/index.node.js";

describe("defineCapability", () => {
	it("accepts a complete definition", () => {
		const def = defineCapability({
			id: "demo",
			schema: z.object({}),
			risk: "low",
			permission: "demo:invoke",
		});
		expect(def.id).toBe("demo");
	});

	it("throws when schema is missing", () => {
		expect(() =>
			defineCapability({ id: "demo", risk: "low", permission: "x" } as never),
		).toThrow(/schema/);
	});

	it("throws when risk is missing or invalid", () => {
		expect(() =>
			defineCapability({
				id: "demo",
				schema: z.object({}),
				permission: "x",
			} as never),
		).toThrow(/risk/);
	});

	it("throws when permission is missing", () => {
		expect(() =>
			defineCapability({
				id: "demo",
				schema: z.object({}),
				risk: "low",
			} as never),
		).toThrow(/permission/);
	});
});

describe("CapabilityRegistry", () => {
	it("registers and looks up the hello capability", () => {
		const registry = new CapabilityRegistry();
		registry.register(helloCapability);

		expect(registry.has("hello")).toBe(true);
		expect(registry.get("hello")?.risk).toBe("low");
		expect(registry.get("unknown")).toBeUndefined();
	});

	it("validates hello params through its schema", () => {
		expect(helloCapability.schema.safeParse({ greeting: "hi" }).success).toBe(
			true,
		);
		expect(helloCapability.schema.safeParse({ greeting: 123 }).success).toBe(
			false,
		);
	});
});
