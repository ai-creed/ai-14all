import { describe, expect, it } from "vitest";
import {
	RELAY_CLOSE_ACCEPT_TIMEOUT,
	RELAY_CLOSE_BAD_AUTH,
	RELAY_CLOSE_HOST_NOT_REGISTERED,
	RELAY_CLOSE_PROTOCOL_VIOLATION,
	deriveHostId,
	parseRelayHostBound,
	parseRelayHostSent,
} from "../../src/protocol/relay.js";
import { fromHex, toHex } from "../../src/encoding.js";

describe("relay control protocol", () => {
	// Correctly sized fixtures: the schemas length-pin every hex field.
	const PUB = "ab".repeat(32); // 64 hex chars — 32-byte pubkey
	const SIG = "cd".repeat(64); // 128 hex chars — 64-byte signature
	const NONCE = "01".repeat(32);
	const HOST_ID = "ff".repeat(32);
	const TOKEN = "aa".repeat(16);

	it("round-trips every host-sent message", () => {
		expect(parseRelayHostSent(JSON.stringify({ t: "register", signPubHex: PUB }))).toEqual({
			t: "register",
			signPubHex: PUB,
		});
		expect(
			parseRelayHostSent(JSON.stringify({ t: "challenge-response", sigHex: SIG })),
		).toEqual({ t: "challenge-response", sigHex: SIG });
	});

	it("round-trips every host-bound message", () => {
		expect(parseRelayHostBound(JSON.stringify({ t: "challenge", nonceHex: NONCE }))).toEqual({
			t: "challenge",
			nonceHex: NONCE,
		});
		expect(parseRelayHostBound(JSON.stringify({ t: "registered", hostId: HOST_ID }))).toEqual({
			t: "registered",
			hostId: HOST_ID,
		});
		expect(
			parseRelayHostBound(JSON.stringify({ t: "incoming-session", token: TOKEN })),
		).toEqual({ t: "incoming-session", token: TOKEN });
	});

	it("rejects malformed, unknown-tag, wrong-direction, and non-JSON input", () => {
		expect(parseRelayHostSent("not json")).toBeNull();
		expect(parseRelayHostSent(JSON.stringify({ t: "nope" }))).toBeNull();
		expect(parseRelayHostSent(JSON.stringify({ t: "register" }))).toBeNull(); // missing field
		expect(parseRelayHostSent(JSON.stringify({ t: "challenge", nonceHex: NONCE }))).toBeNull(); // wrong direction
		expect(parseRelayHostBound(JSON.stringify({ t: "register", signPubHex: PUB }))).toBeNull();
	});

	it("rejects wrong-length or non-hex crypto fields BEFORE any crypto can run", () => {
		expect(parseRelayHostSent(JSON.stringify({ t: "register", signPubHex: "a1b2" }))).toBeNull(); // 2 bytes, not 32
		expect(
			parseRelayHostSent(JSON.stringify({ t: "register", signPubHex: "zz".repeat(32) })),
		).toBeNull(); // non-hex
		expect(
			parseRelayHostSent(JSON.stringify({ t: "challenge-response", sigHex: "00" })),
		).toBeNull(); // 1 byte, not 64 — would make libsodium throw if it ever reached verify
		expect(parseRelayHostBound(JSON.stringify({ t: "incoming-session", token: "aa" }))).toBeNull();
	});

	it("pins the close codes", () => {
		expect(RELAY_CLOSE_PROTOCOL_VIOLATION).toBe(4400);
		expect(RELAY_CLOSE_BAD_AUTH).toBe(4401);
		expect(RELAY_CLOSE_HOST_NOT_REGISTERED).toBe(4404);
		expect(RELAY_CLOSE_ACCEPT_TIMEOUT).toBe(4408);
	});

	it("derives hostId as hex of a 32-byte backend hash of the sign pubkey", () => {
		// Fake backend: hash = first `length` bytes of the message repeated/truncated,
		// so the vector is deterministic without libsodium.
		const backend = {
			hash: (message: Uint8Array, length: number) => {
				const out = new Uint8Array(length);
				for (let i = 0; i < length; i++) out[i] = message[i % message.length]!;
				return out;
			},
		};
		const signPub = fromHex("a1b2");
		const id = deriveHostId(backend, signPub);
		expect(id).toHaveLength(64); // 32 bytes hex
		expect(id).toBe(toHex(backend.hash(signPub, 32)));
	});
});
