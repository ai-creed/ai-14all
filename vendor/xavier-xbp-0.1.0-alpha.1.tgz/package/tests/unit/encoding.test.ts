import { describe, expect, it } from "vitest";
import {
	compareBytes,
	concatBytes,
	fromHex,
	fromUtf8,
	toHex,
	utf8,
} from "../../src/index.node.js";

describe("encoding", () => {
	it("round-trips hex", () => {
		const bytes = new Uint8Array([0, 1, 15, 16, 255]);
		expect(toHex(bytes)).toBe("00010f10ff");
		expect(fromHex("00010f10ff")).toEqual(bytes);
	});

	it("round-trips utf8", () => {
		expect(fromUtf8(utf8("héllo"))).toBe("héllo");
	});

	it("concatenates byte arrays", () => {
		expect(concatBytes(new Uint8Array([1, 2]), new Uint8Array([3]))).toEqual(
			new Uint8Array([1, 2, 3]),
		);
	});

	it("compares bytes lexicographically", () => {
		expect(
			compareBytes(new Uint8Array([1, 2]), new Uint8Array([1, 3])),
		).toBeLessThan(0);
		expect(compareBytes(new Uint8Array([1]), new Uint8Array([1]))).toBe(0);
		expect(
			compareBytes(new Uint8Array([2]), new Uint8Array([1, 9])),
		).toBeGreaterThan(0);
	});
});
