import { writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import {
	createNodeSodiumBackend,
	deriveNodeId,
	generateIdentity,
	type Identity,
	PROTOCOL_VERSION,
	sealAndSign,
	serializeIdentity,
	toHex,
	utf8,
} from "../src/index.node.js";

// Known-answer + negative vectors for the native (Swift) NSE XBP client.
// Valid cases must open+verify; tampered/forged/replay/stale must reject,
// fail-closed. Run: pnpm --filter @xavier/xbp exec tsx scripts/generate-nse-vectors.ts

// Mirrors AntiReplay's DEFAULT window (src/reference/anti-replay.ts:10), which
// Peer uses unmodified (src/peer/peer.ts:106). The native client must enforce
// the same bound — the 29s/31s boundary pair below fails any wider window.
const MAX_SKEW_MS = 30_000;
const NOW_MS = 1_760_000_000_000;

const backend = await createNodeSodiumBackend();
const phone = generateIdentity(backend);
const host = generateIdentity(backend);

const request = {
	v: PROTOCOL_VERSION,
	kind: "request",
	requestId: "req-kat-1",
	capabilityId: "xavier.control.session-report",
	args: {},
	nonce: "kat-nonce-1",
	ts: NOW_MS,
};
const payloadBytes = utf8(JSON.stringify(request));
const sealed = sealAndSign(
	backend,
	payloadBytes,
	phone.sign.privateKey,
	host.box.publicKey,
);

// Negative 1: flip one ciphertext byte.
const tampered = new Uint8Array(sealed);
tampered[tampered.length - 1] ^= 0x01;

// Negative 2: signature from the WRONG key (host signs, claims to be phone).
const forged = sealAndSign(
	backend,
	payloadBytes,
	host.sign.privateKey,
	host.box.publicKey,
);

const ackBase = {
	v: PROTOCOL_VERSION,
	kind: "ack",
	requestId: "req-kat-1",
	ok: true,
	result: { mode: "ready", focus: null, sessions: [] },
	nonce: "ack-nonce-1",
	ts: NOW_MS + 500,
};

function keys(id: Identity) {
	const f = serializeIdentity(id);
	return {
		signPubHex: f.signPublicKeyHex,
		signPrivHex: f.signPrivateKeyHex,
		boxPubHex: f.boxPublicKeyHex,
		boxPrivHex: f.boxPrivateKeyHex,
	};
}

const vectors = {
	protocolVersion: PROTOCOL_VERSION,
	maxSkewMs: MAX_SKEW_MS,
	phone: {
		...keys(phone),
		nodeId: deriveNodeId(backend, phone.sign.publicKey),
	},
	host: { ...keys(host), nodeId: deriveNodeId(backend, host.sign.publicKey) },
	cases: [
		{
			name: "valid-request-roundtrip",
			payloadJson: JSON.stringify(request),
			sealedHex: toHex(sealed),
			expect: "open-ok",
		},
		{
			name: "tampered-ciphertext",
			sealedHex: toHex(tampered),
			expect: "reject",
		},
		{ name: "forged-signature", sealedHex: toHex(forged), expect: "reject" },
		{
			name: "replayed-nonce-ack",
			ackJson: JSON.stringify(ackBase),
			priorNonces: ["ack-nonce-1"],
			nowMs: NOW_MS + 1_000,
			expect: "reject",
		},
		{
			name: "fresh-29s-ack",
			ackJson: JSON.stringify({
				...ackBase,
				nonce: "ack-nonce-29s",
				ts: NOW_MS - 29_000,
			}),
			priorNonces: [],
			nowMs: NOW_MS,
			expect: "accept",
		},
		{
			name: "stale-31s-ack",
			ackJson: JSON.stringify({
				...ackBase,
				nonce: "ack-nonce-31s",
				ts: NOW_MS - 31_000,
			}),
			priorNonces: [],
			nowMs: NOW_MS,
			expect: "reject",
		},
	],
};

const here = dirname(fileURLToPath(import.meta.url));
writeFileSync(
	join(here, "../../../apps/phone/native/nse/ConformanceVectors.json"),
	JSON.stringify(vectors, null, "\t"),
);
console.log("wrote ConformanceVectors.json");
