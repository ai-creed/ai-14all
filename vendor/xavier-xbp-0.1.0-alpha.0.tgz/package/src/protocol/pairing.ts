import { z } from "zod";

// The pairing offer is the out-of-band handshake payload the host renders as a
// QR and the phone scans. It is untrusted input on the phone side, so it gets a
// zod validator. These are the same fields ReferenceHost.createPairingOffer
// produces; this is a relocation of the type plus a parser, not a wire change.
export const PairingOffer = z.object({
	token: z.string(),
	signPubHex: z.string(),
	boxPubHex: z.string(),
	connect: z.object({ url: z.string() }),
	expiresAt: z.number(),
});
export type PairingOffer = z.infer<typeof PairingOffer>;

export function parsePairingOffer(text: string): PairingOffer | null {
	try {
		const parsed = PairingOffer.safeParse(JSON.parse(text));
		return parsed.success ? parsed.data : null;
	} catch {
		return null;
	}
}
