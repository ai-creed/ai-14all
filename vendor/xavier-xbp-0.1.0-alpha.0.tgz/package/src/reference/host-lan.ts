import { createInterface } from "node:readline";
import { pathToFileURL } from "node:url";
import qrcode from "qrcode-terminal";
import { createNodeSodiumBackend } from "../crypto/node-backend.js";
import { generateIdentity } from "../crypto/identity.js";
import { AntiReplay } from "./anti-replay.js";
import { AuditLog } from "./audit.js";
import { CapabilityRegistry, helloCapability } from "../protocol/registry.js";
import { ReferenceHost } from "./host.js";
import { getLanAddress } from "./lan.js";
import { startWebSocketHost } from "../transport/websocket.js";
import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { Peer } from "../peer/peer.js";
import { exposeSessionReport, emitSampleSessionChanged } from "./peer-host.js";
import { sessionReportCapability } from "@ai-creed/command-contract";

// Interactive LAN host for the 0b.1b phone proof. Binds to all interfaces,
// prints its LAN IP/port, renders the pairing offer as a terminal QR, prompts
// the operator to confirm the SAS shown on the phone, and lets the operator
// toggle the kill switch mid-session ('k') to demonstrate the host-side kill
// against the real phone. Not part of CI; exercised by the acceptance run (Task 10).
async function main(): Promise<void> {
	const backend = await createNodeSodiumBackend();
	const registry = new CapabilityRegistry();
	registry.register(helloCapability);
	const audit = new AuditLog(
		join(mkdtempSync(join(tmpdir(), "xbp-lan-")), "audit.jsonl"),
	);
	const identity = generateIdentity(backend);
	const host = new ReferenceHost({
		backend,
		identity,
		registry,
		antiReplay: new AntiReplay(),
		audit,
		handlers: {
			hello: (params) => ({
				youSaid: (params as { greeting: string }).greeting,
			}),
		},
	});

	const ip = getLanAddress();
	if (!ip) {
		console.error("No LAN interface found. Connect to Wi-Fi and retry.");
		process.exit(1);
	}
	const wsHost = await startWebSocketHost(0, "0.0.0.0");
	const url = `ws://${ip}:${wsHost.port}`;
	const offer = host.createPairingOffer({ url });

	console.log(`\nXBP reference host listening on ${url}`);
	console.log("Scan this QR with the phone to pair:\n");
	qrcode.generate(JSON.stringify(offer), { small: true });
	console.log(`\nOffer (text): ${JSON.stringify(offer)}\n`);

	let prompted = false;
	const transport = await wsHost.nextConnection();
	transport.onFrame((frame) => {
		const ack = host.handle(frame);
		if (ack) {
			void transport.send(ack);
		}
		if (host.lastSas && !host.isPaired && !prompted) {
			prompted = true;
			console.log(
				`\nHost SAS = ${host.lastSas}\nType 'y' to confirm (matches the phone) or 'n' to reject.`,
			);
		}
	});

	// Line-based operator console: confirm/reject the SAS, and toggle the host
	// kill switch mid-session so the host-side kill can be demonstrated against
	// the real phone (host rejects + audits the hello; the phone surfaces it).
	console.log(
		"\nCommands: y = confirm SAS · n = reject SAS · k = toggle kill switch · q = quit\n",
	);
	const rl = createInterface({ input: process.stdin });
	rl.on("line", (line) => {
		const cmd = line.trim().toLowerCase();
		if (cmd === "y" || cmd === "n") {
			if (host.lastSas && !host.isPaired) {
				host.confirmPairing(cmd === "y");
				console.log(
					cmd === "y" ? "Paired. Awaiting hello…" : "Rejected (SAS mismatch).",
				);
				if (cmd === "y") {
					// After pairing is confirmed and the active peer is known:
					const peerKeys = host.activePeer();
					if (peerKeys) {
						const peer = new Peer({ backend, identity, transport, audit });
						const phoneNode = peer.addPeer(
							peerKeys.signPub,
							peerKeys.boxPub,
							[sessionReportCapability.permission],
						);
						exposeSessionReport(peer);
						peer.start();
						// Emit one sample event a moment after the phone is ready to call.
						const t = setTimeout(() => emitSampleSessionChanged(peer, phoneNode), 1500);
						(t as { unref?: () => void }).unref?.();
					}
				}
			} else {
				console.log("No pending SAS to confirm.");
			}
		} else if (cmd === "k") {
			host.killSwitch = !host.killSwitch;
			console.log(
				`Kill switch ${
					host.killSwitch
						? "ENABLED — host will reject and audit further hellos"
						: "disabled"
				}.`,
			);
		} else if (cmd === "q") {
			process.exit(0);
		} else {
			console.log("Commands: y · n · k · q");
		}
	});

	console.log("\nAudit log entries print as decisions are made.");
	const seen = new Set<string>();
	setInterval(() => {
		for (const entry of audit.entries()) {
			const key = JSON.stringify(entry);
			if (!seen.has(key)) {
				seen.add(key);
				console.log(`  audit ${key}`);
			}
		}
	}, 250).unref();
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
	void main();
}
