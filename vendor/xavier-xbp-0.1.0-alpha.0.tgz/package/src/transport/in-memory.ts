import type { Transport } from "./transport.js";

class InMemoryEndpoint implements Transport {
	private readonly handlers = new Set<(frame: Uint8Array) => void>();
	private peer: InMemoryEndpoint | null = null;
	private closed = false;

	link(peer: InMemoryEndpoint): void {
		this.peer = peer;
	}

	async send(frame: Uint8Array): Promise<void> {
		const peer = this.peer;
		if (!peer || this.closed) {
			return;
		}
		await Promise.resolve();
		if (peer.closed) {
			return;
		}
		for (const handler of peer.handlers) {
			handler(frame);
		}
	}

	onFrame(handler: (frame: Uint8Array) => void): () => void {
		this.handlers.add(handler);
		return () => this.handlers.delete(handler);
	}

	async close(): Promise<void> {
		this.closed = true;
		this.handlers.clear();
	}
}

export function createInMemoryPair(): [Transport, Transport] {
	const a = new InMemoryEndpoint();
	const b = new InMemoryEndpoint();
	a.link(b);
	b.link(a);
	return [a, b];
}
