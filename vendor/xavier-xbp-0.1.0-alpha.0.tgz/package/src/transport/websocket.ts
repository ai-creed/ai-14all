import { WebSocket, WebSocketServer } from "ws";
import type { Transport } from "./transport.js";

function toUint8Array(data: unknown): Uint8Array {
	if (data instanceof ArrayBuffer) {
		return new Uint8Array(data);
	}
	if (Array.isArray(data)) {
		return new Uint8Array(Buffer.concat(data as Buffer[]));
	}
	return new Uint8Array(data as Buffer);
}

function wrapSocket(socket: WebSocket): Transport {
	const handlers = new Set<(frame: Uint8Array) => void>();
	socket.on("message", (data) => {
		const frame = toUint8Array(data);
		for (const handler of handlers) {
			handler(frame);
		}
	});

	return {
		async send(frame: Uint8Array): Promise<void> {
			await new Promise<void>((resolve, reject) => {
				socket.send(frame, (err) => (err ? reject(err) : resolve()));
			});
		},
		onFrame(handler) {
			handlers.add(handler);
			return () => handlers.delete(handler);
		},
		async close(): Promise<void> {
			handlers.clear();
			socket.close();
		},
	};
}

export interface WebSocketHost {
	port: number;
	nextConnection(): Promise<Transport>;
	close(): Promise<void>;
}

export async function startWebSocketHost(
	port = 0,
	host = "127.0.0.1",
): Promise<WebSocketHost> {
	const server = new WebSocketServer({ port, host });
	await new Promise<void>((resolve) =>
		server.once("listening", () => resolve()),
	);
	const address = server.address();
	const boundPort =
		typeof address === "object" && address ? address.port : port;

	const pending: WebSocket[] = [];
	const waiters: Array<(socket: WebSocket) => void> = [];
	server.on("connection", (socket) => {
		const waiter = waiters.shift();
		if (waiter) {
			waiter(socket);
		} else {
			pending.push(socket);
		}
	});

	return {
		port: boundPort,
		async nextConnection(): Promise<Transport> {
			const ready = pending.shift();
			if (ready) {
				return wrapSocket(ready);
			}
			const socket = await new Promise<WebSocket>((resolve) =>
				waiters.push(resolve),
			);
			return wrapSocket(socket);
		},
		async close(): Promise<void> {
			await new Promise<void>((resolve) => server.close(() => resolve()));
		},
	};
}

export async function connectWebSocketClient(url: string): Promise<Transport> {
	const socket = new WebSocket(url);
	await new Promise<void>((resolve, reject) => {
		socket.once("open", () => resolve());
		socket.once("error", reject);
	});
	return wrapSocket(socket);
}
