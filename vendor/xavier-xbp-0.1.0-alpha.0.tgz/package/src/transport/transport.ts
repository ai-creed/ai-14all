export interface Transport {
	send(frame: Uint8Array): Promise<void>;
	onFrame(handler: (frame: Uint8Array) => void): () => void;
	close(): Promise<void>;
}
