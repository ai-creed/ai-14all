import { describe, expect, it } from "vitest";
import { parsePairingOffer } from "../../../src/index.js";

describe("parsePairingOffer", () => {
	const valid = {
		token: "abc123",
		signPubHex: "00",
		boxPubHex: "11",
		connect: { url: "ws://192.168.1.5:4500" },
		expiresAt: 1000,
	};

	it("parses a well-formed offer", () => {
		expect(parsePairingOffer(JSON.stringify(valid))).toEqual(valid);
	});

	it("returns null for non-JSON input", () => {
		expect(parsePairingOffer("not json")).toBeNull();
	});

	it("returns null when a required field is missing", () => {
		// eslint-disable-next-line @typescript-eslint/no-unused-vars
		const { token: _token, ...rest } = valid;
		expect(parsePairingOffer(JSON.stringify(rest))).toBeNull();
	});

	it("returns null when connect.url is the wrong type", () => {
		const bad = { ...valid, connect: { url: 42 } };
		expect(parsePairingOffer(JSON.stringify(bad))).toBeNull();
	});
});
