import { describe, expect, it } from "vitest";
import { createInMemoryPair } from "../../../src/index.node.js";

describe("in-memory transport", () => {
	it("delivers a frame from one end to the other", async () => {
		const [a, b] = createInMemoryPair();
		const received: string[] = [];
		b.onFrame((frame) => received.push(new TextDecoder().decode(frame)));

		await a.send(new TextEncoder().encode("ping"));
		await new Promise((resolve) => setTimeout(resolve, 0));

		expect(received).toEqual(["ping"]);
	});

	it("stops delivering after unsubscribe", async () => {
		const [a, b] = createInMemoryPair();
		const received: string[] = [];
		const off = b.onFrame((frame) =>
			received.push(new TextDecoder().decode(frame)),
		);
		off();

		await a.send(new TextEncoder().encode("ping"));
		await new Promise((resolve) => setTimeout(resolve, 0));

		expect(received).toEqual([]);
	});

	it("does not deliver after close", async () => {
		const [a, b] = createInMemoryPair();
		const received: string[] = [];
		b.onFrame((frame) => received.push(new TextDecoder().decode(frame)));
		await b.close();

		await a.send(new TextEncoder().encode("ping"));
		await new Promise((resolve) => setTimeout(resolve, 0));

		expect(received).toEqual([]);
	});
});
