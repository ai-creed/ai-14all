import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import {
	AntiReplay,
	AuditLog,
	CapabilityRegistry,
	createNodeSodiumBackend,
	decodeFrame,
	generateIdentity,
	helloCapability,
	PairAccept,
	ReferenceClient,
	ReferenceHost,
} from "../../src/index.node.js";

describe("pairing + hello", () => {
	let dir: string;

	beforeEach(() => {
		dir = mkdtempSync(join(tmpdir(), "xbp-e2e-"));
	});

	afterEach(() => {
		rmSync(dir, { recursive: true, force: true });
	});

	it("pairs with a matching SAS and round-trips a hello", async () => {
		const backend = await createNodeSodiumBackend();
		const registry = new CapabilityRegistry();
		registry.register(helloCapability);

		const host = new ReferenceHost({
			backend,
			identity: generateIdentity(backend),
			registry,
			antiReplay: new AntiReplay(),
			audit: new AuditLog(join(dir, "audit.jsonl")),
			handlers: {
				hello: (params) => ({
					youSaid: (params as { greeting: string }).greeting,
				}),
			},
		});
		const client = new ReferenceClient({
			backend,
			identity: generateIdentity(backend),
		});

		const offer = host.createPairingOffer();
		const acceptBytes = host.handle(client.buildPairRequest(offer.token));
		expect(acceptBytes).not.toBeNull();

		const accept = PairAccept.parse(decodeFrame(acceptBytes!));
		const clientSas = client.acceptPairResponse(accept, offer);

		// Keys are pending until the SAS is confirmed.
		expect(host.isPaired).toBe(false);
		expect(clientSas).toBe(host.lastSas);

		const match = clientSas === host.lastSas;
		expect(host.confirmPairing(match)).toBe(true);
		expect(client.confirmPairing(match)).toBe(true);
		expect(host.isPaired).toBe(true);

		const ackBytes = host.handle(
			client.buildRequest("hello", { greeting: "hi" }),
		);
		const ack = client.openAck(ackBytes!);

		expect(ack?.ok).toBe(true);
		expect(ack?.cap).toBe("hello");
		expect(ack?.result).toEqual({ youSaid: "hi" });
	});

	it("rejects a substituted-key pairing (SAS mismatch) and stores no peer", async () => {
		const backend = await createNodeSodiumBackend();
		const registry = new CapabilityRegistry();
		registry.register(helloCapability);
		const audit = new AuditLog(join(dir, "audit.jsonl"));

		const host = new ReferenceHost({
			backend,
			identity: generateIdentity(backend),
			registry,
			antiReplay: new AntiReplay(),
			audit,
			handlers: { hello: () => ({}) },
		});
		const client = new ReferenceClient({
			backend,
			identity: generateIdentity(backend),
		});

		const offer = host.createPairingOffer();
		const accept = PairAccept.parse(
			decodeFrame(host.handle(client.buildPairRequest(offer.token))!),
		);

		const attacker = backend.generateBoxKeyPair();
		const tamperedOffer = {
			...offer,
			boxPubHex: Buffer.from(attacker.publicKey).toString("hex"),
		};
		const clientSas = client.acceptPairResponse(accept, tamperedOffer);

		const match = clientSas === host.lastSas;
		expect(match).toBe(false);
		expect(host.confirmPairing(match)).toBe(false);
		expect(client.confirmPairing(match)).toBe(false);

		expect(host.isPaired).toBe(false);
		expect(audit.entries().at(-1)).toMatchObject({
			cap: "pairing",
			outcome: "rejected",
			reason: "sas-mismatch",
		});

		// With no peer stored, the client cannot build requests and the host rejects work.
		expect(() => client.buildRequest("hello", { greeting: "hi" })).toThrow();
	});

	it("includes host keys, connection info, and an expiry in the offer", async () => {
		const backend = await createNodeSodiumBackend();
		const registry = new CapabilityRegistry();
		registry.register(helloCapability);
		const host = new ReferenceHost({
			backend,
			identity: generateIdentity(backend),
			registry,
			antiReplay: new AntiReplay(),
			audit: new AuditLog(join(dir, "audit.jsonl")),
			handlers: { hello: () => ({}) },
			pairingTokenTtlMs: 60_000,
			now: () => 1_000,
		});

		const offer = host.createPairingOffer({ url: "ws://127.0.0.1:7777" });

		expect(offer.token.length).toBeGreaterThan(0);
		expect(offer.signPubHex.length).toBeGreaterThan(0);
		expect(offer.boxPubHex.length).toBeGreaterThan(0);
		expect(offer.connect).toEqual({ url: "ws://127.0.0.1:7777" });
		expect(offer.expiresAt).toBe(61_000);
	});

	it("rejects a pairing request after the token has expired", async () => {
		const backend = await createNodeSodiumBackend();
		const registry = new CapabilityRegistry();
		registry.register(helloCapability);
		let clock = 1_000;
		const audit = new AuditLog(join(dir, "audit.jsonl"));
		const host = new ReferenceHost({
			backend,
			identity: generateIdentity(backend),
			registry,
			antiReplay: new AntiReplay(),
			audit,
			handlers: { hello: () => ({}) },
			pairingTokenTtlMs: 5_000,
			now: () => clock,
		});
		const client = new ReferenceClient({
			backend,
			identity: generateIdentity(backend),
		});

		const offer = host.createPairingOffer();
		clock = offer.expiresAt + 1;
		const result = host.handle(client.buildPairRequest(offer.token));

		expect(result).toBeNull();
		expect(host.isPaired).toBe(false);
		expect(audit.entries().at(-1)?.reason).toBe("pairing-token-expired");
	});
});
